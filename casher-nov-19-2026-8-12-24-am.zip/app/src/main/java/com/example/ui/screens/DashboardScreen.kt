package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.Product
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.hardware.BluetoothScannerStatus
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.viewmodel.CasherViewModel
import java.util.Locale

@Composable
fun DashboardScreen(
    profileState: UiState<StoreProfile>,
    productsState: UiState<List<Product>>,
    invoicesState: UiState<List<Invoice>>,
    expensesState: UiState<List<Expense>>,
    btStatus: BluetoothScannerStatus,
    isVaultUnlocked: Boolean,
    onNavigateNewInvoice: () -> Unit,
    onNavigateInventory: () -> Unit,
    onNavigateInvoicesHistory: () -> Unit,
    onNavigateReportsAndExpenses: () -> Unit,
    onNavigateSearch: () -> Unit,
    onNavigateSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val profile = (profileState as? UiState.Success)?.data ?: StoreProfile()
    val products = (productsState as? UiState.Success)?.data ?: emptyList()
    val invoices = (invoicesState as? UiState.Success)?.data ?: emptyList()
    val expenses = (expensesState as? UiState.Success)?.data ?: emptyList()

    val todayKey = CasherViewModel.todayDayKey()
    val todaySales = invoices.filter { it.dayKey == todayKey }.sumOf { it.totalAmount }
    val todayExpenses = expenses.filter { it.dayKey == todayKey }.sumOf { it.amount }
    val lowStockCount = products.count { it.quantity <= (it.minStockAlert ?: 5L) }
    val hideNumbers = profile.pinEnabled && !isVaultUnlocked

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(EmeraldDeep, EmeraldPrimary)
                        )
                    )
                    .padding(20.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "أهلاً بك في casher",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color(0xFFA7F3D0)
                            )
                            Text(
                                text = profile.storeName,
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row {
                            IconButton(
                                onClick = onNavigateSearch,
                                modifier = Modifier.testTag("dashboard_search_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "البحث داخل التطبيق",
                                    tint = Color.White
                                )
                            }
                            IconButton(
                                onClick = onNavigateSettings,
                                modifier = Modifier.testTag("dashboard_settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "الإعدادات",
                                    tint = Color.White
                                )
                            }
                        }
                    }

                    // Sync & Bluetooth Status Row
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusChip(
                            icon = Icons.Default.CloudDone,
                            text = "مزامنة سحابية نشطة",
                            containerColor = Color.White.copy(alpha = 0.16f),
                            contentColor = Color(0xFFD1FAE5)
                        )
                        StatusChip(
                            icon = if (btStatus is BluetoothScannerStatus.Connected) {
                                Icons.Default.BluetoothConnected
                            } else {
                                Icons.Default.BluetoothDisabled
                            },
                            text = when (btStatus) {
                                is BluetoothScannerStatus.Connected -> "ماسح: ${btStatus.deviceName}"
                                is BluetoothScannerStatus.Connecting -> "جاري الربط..."
                                else -> "بلوتوث غير متصل"
                            },
                            containerColor = Color.White.copy(alpha = 0.16f),
                            contentColor = Color.White
                        )
                    }

                    // Today's Financial Pulse
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PulseMetricBox(
                            label = "مبيعات اليوم",
                            value = if (hideNumbers) "••••" else "${formatMoney(todaySales)} ${profile.currency}",
                            icon = if (hideNumbers) Icons.Default.Lock else Icons.Default.TrendingUp,
                            modifier = Modifier.weight(1f)
                        )
                        PulseMetricBox(
                            label = "مصاريف اليوم",
                            value = if (hideNumbers) "••••" else "${formatMoney(todayExpenses)} ${profile.currency}",
                            icon = if (hideNumbers) Icons.Default.Lock else Icons.Default.TrendingDown,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Primary POS Actions Title
        item {
            Text(
                text = "العمليات الرئيسية",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        // 2x2 Quick Action Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    DashboardActionCard(
                        title = "إضافة فاتورة جديدة",
                        subtitle = "مسح QR / تعديل السعر / طباعة PDF",
                        icon = Icons.Default.AddShoppingCart,
                        accentColor = MaterialTheme.colorScheme.primary,
                        onClick = onNavigateNewInvoice,
                        modifier = Modifier.weight(1f).testTag("card_new_invoice")
                    )
                    DashboardActionCard(
                        title = "المخزون",
                        subtitle = "${products.size} صنف • مسح الباركود",
                        icon = Icons.Default.Inventory2,
                        accentColor = MaterialTheme.colorScheme.secondary,
                        onClick = onNavigateInventory,
                        modifier = Modifier.weight(1f).testTag("card_inventory")
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    DashboardActionCard(
                        title = "سجل الفواتير",
                        subtitle = "${invoices.size} فاتورة محفوظة",
                        icon = Icons.AutoMirrored.Filled.ReceiptLong,
                        accentColor = MaterialTheme.colorScheme.tertiary,
                        onClick = onNavigateInvoicesHistory,
                        modifier = Modifier.weight(1f).testTag("card_invoices_history")
                    )
                    DashboardActionCard(
                        title = "المصاريف والتقارير",
                        subtitle = "تقارير يومية وشهرية + Excel",
                        icon = Icons.Default.BarChart,
                        accentColor = Color(0xFF7C3AED),
                        onClick = onNavigateReportsAndExpenses,
                        modifier = Modifier.weight(1f).testTag("card_reports_expenses")
                    )
                }
            }
        }

        // Low stock alert banner if any
        if (lowStockCount > 0) {
            item {
                Card(
                    onClick = onNavigateInventory,
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تنبيه انخفاض المخزون",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "يوجد $lowStockCount منتجات اقتربت كميتها من النفاد. اضغط للمراجعة.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusChip(
    icon: ImageVector,
    text: String,
    containerColor: Color,
    contentColor: Color
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = containerColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = contentColor, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text(text = text, style = MaterialTheme.typography.labelMedium, color = contentColor)
        }
    }
}

@Composable
private fun PulseMetricBox(
    label: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.14f),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.2f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(label, style = MaterialTheme.typography.labelMedium, color = Color(0xFFD1FAE5))
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun DashboardActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .height(146.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = accentColor.copy(alpha = 0.14f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }
        }
    }
}

fun formatMoney(value: Double): String {
    return String.format(Locale.US, "%.2f", value)
}
