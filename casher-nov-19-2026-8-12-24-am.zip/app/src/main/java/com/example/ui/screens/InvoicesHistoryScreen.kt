package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Invoice
import com.example.data.model.PaymentMethod
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.export.InvoicePdfExporter
import com.example.ui.theme.MonoFontFamily
import com.example.viewmodel.CasherViewModel
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvoicesHistoryScreen(
    invoicesState: UiState<List<Invoice>>,
    profileState: UiState<StoreProfile>,
    viewModel: CasherViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile = (profileState as? UiState.Success)?.data ?: StoreProfile()
    var query by remember { mutableStateOf("") }
    var selectedInvoice by remember { mutableStateOf<Invoice?>(null) }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        val inv = selectedInvoice
        if (uri != null && inv != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    InvoicePdfExporter.writeInvoicePdf(inv, profile.storeName, profile.currency, out)
                }
                viewModel.showFeedback("تم حفظ الفاتورة بصيغة PDF بنجاح")
            } catch (e: Exception) {
                viewModel.showFeedback("تعذر حفظ ملف PDF: ${e.localizedMessage}")
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("ابحث برقم الفاتورة، العميل، أو اسم المنتج...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().testTag("invoices_search_field")
        )
        Spacer(Modifier.height(12.dp))

        when (invoicesState) {
            is UiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Error -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(invoicesState.message, color = MaterialTheme.colorScheme.error)
                }
            }
            is UiState.Success -> {
                val filtered = invoicesState.data.filter { inv ->
                    query.isBlank() ||
                        inv.invoiceNumber.contains(query, ignoreCase = true) ||
                        (inv.customerName?.contains(query, ignoreCase = true) == true) ||
                        inv.items.any { it.productName.contains(query, ignoreCase = true) }
                }

                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "سجل الفواتير فارغ",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "ستظهر جميع الفواتير المحفوظة هنا مع خيارات الطباعة وتصدير PDF.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(filtered, key = { it.id }) { inv ->
                            val dateStr = inv.createdAt?.toDate()?.let {
                                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(it)
                            } ?: inv.dayKey
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedInvoice = inv }
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = inv.invoiceNumber,
                                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "$dateStr • ${inv.items.size} أصناف",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (!inv.customerName.isNullOrBlank()) {
                                            Text(
                                                text = "العميل: ${inv.customerName}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${formatMoney(inv.totalAmount)} ${profile.currency}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(Modifier.height(4.dp))
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Text(
                                                text = PaymentMethod.fromRaw(inv.paymentMethod).arabicLabel,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val inv = selectedInvoice
    if (inv != null) {
        ModalBottomSheet(
            onDismissRequest = { selectedInvoice = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "تفاصيل الفاتورة ${inv.invoiceNumber}",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "التاريخ: ${inv.dayKey} • الدفع: ${PaymentMethod.fromRaw(inv.paymentMethod).arabicLabel}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                HorizontalDivider()

                inv.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.productName} (${item.quantity} × ${formatMoney(item.unitPrice)})",
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${formatMoney(item.lineTotal)} ${profile.currency}",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider()
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("المجموع الفرعي")
                    Text("${formatMoney(inv.subtotal)} ${profile.currency}")
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("الضريبة")
                    Text("${formatMoney(inv.taxAmount)} ${profile.currency}")
                }
                if (inv.discountAmount > 0.0) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("الخصم")
                        Text("-${formatMoney(inv.discountAmount)} ${profile.currency}")
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("الإجمالي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${formatMoney(inv.totalAmount)} ${profile.currency}",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { savePdfLauncher.launch("${inv.invoiceNumber}.pdf") },
                        modifier = Modifier.weight(1f).testTag("history_save_pdf_button")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("حفظ PDF")
                    }
                    FilledTonalButton(
                        onClick = {
                            InvoicePdfExporter.printInvoice(context, inv, profile.storeName, profile.currency)
                        },
                        modifier = Modifier.weight(1f).testTag("history_print_button")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("طباعة")
                    }
                    IconButton(
                        onClick = {
                            val uri = InvoicePdfExporter.exportInvoiceToCacheAndShare(
                                context,
                                inv,
                                profile.storeName,
                                profile.currency
                            )
                            InvoicePdfExporter.sharePdfUri(context, uri, inv.invoiceNumber)
                        }
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة PDF")
                    }
                }
            }
        }
    }
}
