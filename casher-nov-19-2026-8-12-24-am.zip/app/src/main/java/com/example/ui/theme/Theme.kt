package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldSoft,
    onPrimaryContainer = EmeraldDeep,
    secondary = AmberAccent,
    onSecondary = Color.White,
    secondaryContainer = AmberLight,
    onSecondaryContainer = AmberDark,
    tertiary = InfoBlue,
    onTertiary = Color.White,
    tertiaryContainer = InfoSoft,
    onTertiaryContainer = SlateInk,
    background = SurfaceIvory,
    onBackground = SlateInk,
    surface = SurfaceCardLight,
    onSurface = SlateInk,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = SlateMuted,
    outline = OutlineLight,
    error = DangerRed,
    onError = Color.White,
    errorContainer = DangerSoft,
    onErrorContainer = DangerRed
)

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldBright,
    onPrimary = EmeraldDeep,
    primaryContainer = EmeraldContainerDark,
    onPrimaryContainer = EmeraldSoft,
    secondary = AmberAccent,
    onSecondary = Color.White,
    secondaryContainer = AmberDark,
    onSecondaryContainer = AmberLight,
    tertiary = InfoBlue,
    onTertiary = Color.White,
    background = SurfaceNight,
    onBackground = Color(0xFFE2E8F0),
    surface = SurfaceCardNight,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = SurfaceVariantNight,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = OutlineNight,
    error = Color(0xFFF87171),
    onError = Color(0xFF450A0A),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = DangerSoft
)

private val CasherShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun CasherTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = CasherTypography,
            shapes = CasherShapes,
            content = content
        )
    }
}
