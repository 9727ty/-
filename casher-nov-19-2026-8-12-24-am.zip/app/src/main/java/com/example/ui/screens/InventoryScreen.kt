package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.hardware.BarcodeScannerModalSheet
import com.example.ui.theme.MonoFontFamily
import com.example.viewmodel.CasherViewModel
import kotlinx.coroutines.flow.SharedFlow

@Composable
fun InventoryScreen(
    productsState: UiState<List<Product>>,
    profileState: UiState<StoreProfile>,
    bluetoothScannedCodes: SharedFlow<String>,
    viewModel: CasherViewModel,
    modifier: Modifier = Modifier
) {
    val profile = (profileState as? UiState.Success)?.data ?: StoreProfile()
    var filterQuery by remember { mutableStateOf("") }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showAddEditDialog by remember { mutableStateOf(false) }
    var activeBarcodeInDialog by remember { mutableStateOf("") }
    var showBarcodeScanner by remember { mutableStateOf(false) }

    // Listen for Bluetooth SPP scanner codes while in Inventory
    LaunchedEffect(bluetoothScannedCodes, showAddEditDialog) {
        bluetoothScannedCodes.collect { scannedCode ->
            if (showAddEditDialog) {
                activeBarcodeInDialog = scannedCode
            } else {
                val existing = (productsState as? UiState.Success)?.data
                    ?.firstOrNull { it.barcode.equals(scannedCode, ignoreCase = true) }
                editingProduct = existing
                activeBarcodeInDialog = scannedCode
                showAddEditDialog = true
            }
        }
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingProduct = null
                    activeBarcodeInDialog = ""
                    showAddEditDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.testTag("add_inventory_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة منتج للمخزون")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = filterQuery,
                    onValueChange = { filterQuery = it },
                    placeholder = { Text("ابحث بالاسم أو الباركود...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).testTag("inventory_search_field")
                )
                FilledTonalIconButton(
                    onClick = {
                        editingProduct = null
                        activeBarcodeInDialog = ""
                        showAddEditDialog = true
                        showBarcodeScanner = true
                    },
                    modifier = Modifier.size(52.dp).testTag("inventory_quick_scan_button")
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح باركود لإضافة منتج")
                }
            }

            Spacer(Modifier.height(12.dp))

            when (productsState) {
                is UiState.Loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Error -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(productsState.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                is UiState.Success -> {
                    val filtered = productsState.data.filter {
                        filterQuery.isBlank() ||
                            it.name.contains(filterQuery, ignoreCase = true) ||
                            it.barcode.contains(filterQuery, ignoreCase = true) ||
                            (it.category?.contains(filterQuery, ignoreCase = true) == true)
                    }
                    if (filtered.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Inventory2,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Text(
                                    text = "لا توجد منتجات مطابقة في المخزون",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "اضغط + لإضافة منتج عبر الباركود أو الإدخال اليدوي.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 88.dp)
                        ) {
                            items(filtered, key = { it.id }) { product ->
                                val isLow = product.quantity <= (product.minStockAlert ?: 5L)
                                Card(
                                    shape = RoundedCornerShape(18.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = product.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = product.barcode,
                                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(Modifier.height(6.dp))
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (isLow) MaterialTheme.colorScheme.errorContainer
                                                    else MaterialTheme.colorScheme.primaryContainer
                                                ) {
                                                    Text(
                                                        text = "الكمية: ${product.quantity}",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (isLow) MaterialTheme.colorScheme.onErrorContainer
                                                        else MaterialTheme.colorScheme.onPrimaryContainer,
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "السعر: ${formatMoney(product.unitPrice)} ${profile.currency}",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }

                                        IconButton(
                                            onClick = {
                                                editingProduct = product
                                                activeBarcodeInDialog = product.barcode
                                                showAddEditDialog = true
                                            }
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "تعديل")
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteProduct(product.id) }
                                        ) {
                                            Icon(
                                                Icons.Default.DeleteOutline,
                                                contentDescription = "حذف",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddEditDialog) {
        ProductUpsertDialog(
            initialProduct = editingProduct,
            barcodeValue = activeBarcodeInDialog,
            currency = profile.currency,
            onBarcodeChange = { activeBarcodeInDialog = it },
            onRequestScan = { showBarcodeScanner = true },
            onDismiss = { showAddEditDialog = false },
            onSave = { barcode, name, qty, price, cost, cat, minAlert ->
                viewModel.upsertProduct(
                    existingId = editingProduct?.id ?: "",
                    barcode = barcode,
                    name = name,
                    quantity = qty,
                    unitPrice = price,
                    costPrice = cost,
                    category = cat,
                    minStockAlert = minAlert
                )
                showAddEditDialog = false
            }
        )
    }

    if (showBarcodeScanner) {
        BarcodeScannerModalSheet(
            title = "مسح باركود المنتج للمخزون",
            onBarcodeDetected = { code ->
                activeBarcodeInDialog = code
                showBarcodeScanner = false
            },
            onDismiss = { showBarcodeScanner = false }
        )
    }
}

@Composable
private fun ProductUpsertDialog(
    initialProduct: Product?,
    barcodeValue: String,
    currency: String,
    onBarcodeChange: (String) -> Unit,
    onRequestScan: () -> Unit,
    onDismiss: () -> Unit,
    onSave: (String, String, Long, Double, Double?, String?, Long?) -> Unit
) {
    var name by remember(initialProduct) { mutableStateOf(initialProduct?.name ?: "") }
    var qtyText by remember(initialProduct) { mutableStateOf((initialProduct?.quantity ?: 1L).toString()) }
    var priceText by remember(initialProduct) {
        mutableStateOf(
            initialProduct?.unitPrice?.let { CasherViewModel.formatPriceInput(it) } ?: ""
        )
    }
    var costText by remember(initialProduct) {
        mutableStateOf(
            initialProduct?.costPrice?.let { CasherViewModel.formatPriceInput(it) } ?: ""
        )
    }
    var category by remember(initialProduct) { mutableStateOf(initialProduct?.category ?: "") }
    var minAlertText by remember(initialProduct) {
        mutableStateOf((initialProduct?.minStockAlert ?: 5L).toString())
    }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialProduct == null) "إضافة منتج للمخزون" else "تعديل بيانات المنتج")
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = barcodeValue,
                        onValueChange = onBarcodeChange,
                        label = { Text("الباركود / QR") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("product_barcode_input")
                    )
                    FilledTonalIconButton(
                        onClick = onRequestScan,
                        modifier = Modifier.size(50.dp).testTag("product_scan_barcode_button")
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح بالكاميرا")
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المنتج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("product_name_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it.filter { c -> c.isDigit() } },
                        label = { Text("العدد (الكمية)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("product_qty_input")
                    )
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("السعر ($currency)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("product_price_input")
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = costText,
                        onValueChange = { costText = it },
                        label = { Text("التكلفة (اختياري)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minAlertText,
                        onValueChange = { minAlertText = it.filter { c -> c.isDigit() } },
                        label = { Text("تنبيه النقص") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("التصنيف (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val b = barcodeValue.trim()
                    val n = name.trim()
                    val q = qtyText.toLongOrNull()
                    val p = priceText.replace(',', '.').toDoubleOrNull() ?: 0.0
                    if (b.isEmpty() || n.isEmpty() || q == null) {
                        validationError = "يرجى إدخال الباركود واسم المنتج والعدد الصحيح."
                        return@Button
                    }
                    onSave(
                        b,
                        n,
                        q,
                        p,
                        costText.replace(',', '.').toDoubleOrNull(),
                        category.trim().takeIf { it.isNotEmpty() },
                        minAlertText.toLongOrNull()
                    )
                },
                modifier = Modifier.testTag("save_product_button")
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
