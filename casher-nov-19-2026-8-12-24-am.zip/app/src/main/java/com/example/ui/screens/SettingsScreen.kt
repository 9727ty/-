package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.data.firebase.signOutUser
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.hardware.BluetoothScannerManager
import com.example.hardware.BluetoothScannerStatus
import com.example.hardware.PairedBluetoothDeviceUi
import com.example.viewmodel.CasherViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

@Composable
fun SettingsScreen(
    profileState: UiState<StoreProfile>,
    bluetoothManager: BluetoothScannerManager,
    btStatus: BluetoothScannerStatus,
    viewModel: CasherViewModel,
    onBeforeSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val profile = (profileState as? UiState.Success)?.data ?: StoreProfile()

    var storeName by remember(profile.storeName) { mutableStateOf(profile.storeName) }
    var currency by remember(profile.currency) { mutableStateOf(profile.currency) }
    var taxText by remember(profile.taxRatePercent) {
        mutableStateOf(CasherViewModel.formatPriceInput(profile.taxRatePercent))
    }
    var pinEnabled by remember(profile.pinEnabled) { mutableStateOf(profile.pinEnabled) }
    var newPin by remember { mutableStateOf("") }

    var hasBtPermission by remember { mutableStateOf(bluetoothManager.hasBluetoothPermission()) }
    var pairedDevices by remember { mutableStateOf<List<PairedBluetoothDeviceUi>>(emptyList()) }

    val btPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasBtPermission = results.values.all { it } || bluetoothManager.hasBluetoothPermission()
        if (hasBtPermission) {
            pairedDevices = bluetoothManager.getPairedDevices()
        }
    }

    LaunchedEffect(hasBtPermission) {
        if (hasBtPermission) {
            pairedDevices = bluetoothManager.getPairedDevices()
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Store Configuration
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Store, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("إعدادات المتجر والفواتير", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    OutlinedTextField(
                        value = storeName,
                        onValueChange = { storeName = it },
                        label = { Text("اسم المتجر") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("settings_store_name_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = currency,
                            onValueChange = { currency = it },
                            label = { Text("العملة") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = taxText,
                            onValueChange = { taxText = it },
                            label = { Text("الضريبة (%)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Financial Security System (PIN Protection)
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("نظام حماية المعلومات المالية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("قفل التقارير والمصاريف برمز PIN", fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "يحمي صافي الأرباح والتقارير اليومية والشهرية برمز سري مكون من 4 أرقام.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = pinEnabled,
                            onCheckedChange = { pinEnabled = it },
                            modifier = Modifier.testTag("settings_pin_switch")
                        )
                    }

                    if (pinEnabled) {
                        OutlinedTextField(
                            value = newPin,
                            onValueChange = { input ->
                                if (input.length <= 4 && input.all { it.isDigit() }) {
                                    newPin = input
                                }
                            },
                            label = {
                                Text(
                                    if (profile.pinHash.isNullOrBlank()) "أدخل رمز PIN جديد (4 أرقام)"
                                    else "تغيير رمز PIN (اتركه فارغاً للإبقاء على الحالي)"
                                )
                            },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("settings_pin_input")
                        )
                    }

                    Button(
                        onClick = {
                            if (pinEnabled && profile.pinHash.isNullOrBlank() && newPin.length != 4) {
                                viewModel.showFeedback("يرجى إدخال رمز حماية مكون من 4 أرقام أولاً.")
                                return@Button
                            }
                            viewModel.saveStoreSettings(
                                storeName = storeName,
                                currency = currency,
                                taxRatePercent = taxText.replace(',', '.').toDoubleOrNull() ?: 15.0,
                                pinEnabled = pinEnabled,
                                newRawPin = newPin.takeIf { it.length == 4 },
                                bluetoothScannerName = null,
                                bluetoothScannerAddress = null
                            )
                            newPin = ""
                        },
                        modifier = Modifier.fillMaxWidth().testTag("settings_save_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("حفظ إعدادات المتجر والحماية")
                    }
                }
            }
        }

        // Bluetooth Barcode Scanner Pairing
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (btStatus is BluetoothScannerStatus.Connected) {
                                Icons.Default.BluetoothConnected
                            } else {
                                Icons.Default.Bluetooth
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("ربط ماسح الباركود عبر البلوتوث", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = when (btStatus) {
                            is BluetoothScannerStatus.Connected -> "متصل حالياً بـ: ${btStatus.deviceName} (${btStatus.address})"
                            is BluetoothScannerStatus.Connecting -> "جاري الاتصال بـ ${btStatus.deviceName}..."
                            is BluetoothScannerStatus.Error -> btStatus.message
                            BluetoothScannerStatus.Disconnected -> "غير متصل بأي ماسح SPP. يمكنك أيضاً استخدام ماسح Bluetooth HID مباشرة في حقل الإدخال."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!hasBtPermission) {
                        FilledTonalButton(
                            onClick = {
                                val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    arrayOf(
                                        Manifest.permission.BLUETOOTH_CONNECT,
                                        Manifest.permission.BLUETOOTH_SCAN
                                    )
                                } else {
                                    arrayOf(Manifest.permission.BLUETOOTH)
                                }
                                btPermissionLauncher.launch(perms)
                            },
                            modifier = Modifier.fillMaxWidth().testTag("request_bluetooth_permission_button")
                        ) {
                            Text("منح صلاحية البلوتوث للبحث عن الأجهزة المقترنة")
                        }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = { pairedDevices = bluetoothManager.getPairedDevices() },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("تحديث الأجهزة المقترنة")
                            }
                            if (btStatus is BluetoothScannerStatus.Connected) {
                                OutlinedButton(
                                    onClick = { bluetoothManager.disconnect() },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("قطع الاتصال")
                                }
                            }
                        }

                        if (pairedDevices.isEmpty()) {
                            Text(
                                text = "لا توجد أجهزة بلوتوث مقترنة أو البلوتوث مغلق. قم بإقران الماسح من إعدادات الجهاز أولاً.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            pairedDevices.forEach { device ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(device.name, fontWeight = FontWeight.Bold)
                                            Text(device.address, style = MaterialTheme.typography.labelMedium)
                                        }
                                        Button(
                                            onClick = {
                                                bluetoothManager.connectToDevice(device.address, device.name)
                                                viewModel.saveStoreSettings(
                                                    storeName = storeName,
                                                    currency = currency,
                                                    taxRatePercent = taxText.replace(',', '.').toDoubleOrNull() ?: 15.0,
                                                    pinEnabled = pinEnabled,
                                                    newRawPin = null,
                                                    bluetoothScannerName = device.name,
                                                    bluetoothScannerAddress = device.address
                                                )
                                            }
                                        ) {
                                            Text("ربط")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Account & Sign Out
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val userEmail = Firebase.auth.currentUser?.email ?: "حساب متصل"
                    Text("الحساب السحابي: $userEmail", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                    Button(
                        onClick = {
                            signOutUser(
                                credentialManager = credentialManager,
                                scope = scope,
                                onBeforeSignOut = onBeforeSignOut
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("تسجيل الخروج")
                    }
                }
            }
        }
    }
}
