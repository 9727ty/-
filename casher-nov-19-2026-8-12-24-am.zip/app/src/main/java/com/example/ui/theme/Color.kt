package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Fintech Palette
val EmeraldDeep = Color(0xFF0B3B36)
val EmeraldPrimary = Color(0xFF0E6B58)
val EmeraldBright = Color(0xFF10B981)
val EmeraldSoft = Color(0xFFD1FAE5)
val EmeraldContainerDark = Color(0xFF0D4A3E)

// Warm Gold / Amber Accents
val AmberAccent = Color(0xFFD97706)
val AmberLight = Color(0xFFFEF3C7)
val AmberDark = Color(0xFF78350F)

// Slate & Surface Neutrals
val SlateInk = Color(0xFF0F172A)
val SlateMuted = Color(0xFF475569)
val SurfaceIvory = Color(0xFFF6F9F8)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE9F0EE)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Mode Neutrals
val SurfaceNight = Color(0xFF091311)
val SurfaceCardNight = Color(0xFF11201D)
val SurfaceVariantNight = Color(0xFF1A2E2A)
val OutlineNight = Color(0xFF2D4A43)

// Semantic Status
val DangerRed = Color(0xFFDC2626)
val DangerSoft = Color(0xFFFEE2E2)
val InfoBlue = Color(0xFF0284C7)
val InfoSoft = Color(0xFFE0F2FE)
