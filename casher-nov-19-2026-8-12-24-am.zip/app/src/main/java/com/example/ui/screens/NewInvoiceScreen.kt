package com.example.ui.screens

import android.net.Uri
import android.view.KeyEvent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Invoice
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.export.InvoicePdfExporter
import com.example.hardware.BarcodeScannerModalSheet
import com.example.ui.theme.MonoFontFamily
import com.example.viewmodel.CasherViewModel
import com.example.viewmodel.DraftInvoiceRow
import com.example.viewmodel.InvoiceDraftUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewInvoiceScreen(
    draft: InvoiceDraftUiState,
    profileState: UiState<StoreProfile>,
    productsState: UiState<List<Product>>,
    viewModel: CasherViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val profile = (profileState as? UiState.Success)?.data ?: StoreProfile()
    val products = (productsState as? UiState.Success)?.data ?: emptyList()

    var showScannerSheet by remember { mutableStateOf(false) }
    var showProductPicker by remember { mutableStateOf(false) }
    var quickBarcodeInput by remember { mutableStateOf("") }
    var pendingPdfInvoice by remember { mutableStateOf<Invoice?>(null) }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        val inv = pendingPdfInvoice ?: draft.lastCompletedInvoice
        if (uri != null && inv != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    InvoicePdfExporter.writeInvoicePdf(inv, profile.storeName, profile.currency, out)
                }
                viewModel.showFeedback("تم حفظ الفاتورة بصيغة PDF بنجاح")
            } catch (e: Exception) {
                viewModel.showFeedback("تعذر حفظ ملف PDF: ${e.localizedMessage}")
            }
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Completed Invoice Success & PDF / Print Card
        val completed = draft.lastCompletedInvoice
        if (completed != null) {
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "تم إصدار الفاتورة بنجاح",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "${completed.invoiceNumber} • ${formatMoney(completed.totalAmount)} ${profile.currency}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    pendingPdfInvoice = completed
                                    savePdfLauncher.launch("${completed.invoiceNumber}.pdf")
                                },
                                modifier = Modifier.weight(1f).testTag("save_completed_pdf_button")
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("حفظ PDF")
                            }
                            FilledTonalButton(
                                onClick = {
                                    InvoicePdfExporter.printInvoice(
                                        context,
                                        completed,
                                        profile.storeName,
                                        profile.currency
                                    )
                                },
                                modifier = Modifier.weight(1f).testTag("print_completed_invoice_button")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("طباعة")
                            }
                            IconButton(
                                onClick = {
                                    val uri = InvoicePdfExporter.exportInvoiceToCacheAndShare(
                                        context,
                                        completed,
                                        profile.storeName,
                                        profile.currency
                                    )
                                    InvoicePdfExporter.sharePdfUri(context, uri, completed.invoiceNumber)
                                }
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "مشاركة PDF")
                            }
                        }
                    }
                }
            }
        }

        // Scanner & Quick Add Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "إدخال المنتجات بالباركود أو QR",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showScannerSheet = true },
                            modifier = Modifier.weight(1f).testTag("invoice_scan_qr_button")
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("مسح QR / كاميرا")
                        }
                        FilledTonalButton(
                            onClick = { showProductPicker = true },
                            modifier = Modifier.weight(1f).testTag("invoice_pick_inventory_button")
                        ) {
                            Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("من المخزون")
                        }
                    }

                    // External USB / Bluetooth HID Scanner Rapid Field
                    OutlinedTextField(
                        value = quickBarcodeInput,
                        onValueChange = { value ->
                            if (value.contains('\n')) {
                                val cleaned = value.replace("\n", "").trim()
                                if (cleaned.isNotEmpty()) {
                                    quickBarcodeInput = ""
                                    viewModel.addBarcodeOrProductToInvoice(cleaned)
                                }
                            } else {
                                quickBarcodeInput = value
                            }
                        },
                        label = { Text("ماسح باركود خارجي / إدخال رمز سريع") },
                        placeholder = { Text("امسح بالماسح الخارجي أو اكتب الرمز واضغط تم") },
                        leadingIcon = { Icon(Icons.Default.Usb, contentDescription = null) },
                        trailingIcon = {
                            if (quickBarcodeInput.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        val code = quickBarcodeInput.trim()
                                        if (code.isNotEmpty()) {
                                            quickBarcodeInput = ""
                                            viewModel.addBarcodeOrProductToInvoice(code)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.AddCircleOutline, contentDescription = "إضافة")
                                }
                            }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                val code = quickBarcodeInput.trim()
                                if (code.isNotEmpty()) {
                                    quickBarcodeInput = ""
                                    viewModel.addBarcodeOrProductToInvoice(code)
                                }
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("invoice_external_scanner_field")
                            .onPreviewKeyEvent { event ->
                                if (event.nativeKeyEvent.action == KeyEvent.ACTION_DOWN &&
                                    event.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_ENTER
                                ) {
                                    val code = quickBarcodeInput.trim()
                                    if (code.isNotEmpty()) {
                                        quickBarcodeInput = ""
                                        viewModel.addBarcodeOrProductToInvoice(code)
                                    }
                                    true
                                } else {
                                    false
                                }
                            }
                    )

                    OutlinedButton(
                        onClick = { viewModel.addBlankManualItemToInvoice() },
                        modifier = Modifier.fillMaxWidth().testTag("invoice_add_manual_item_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("إضافة بند يدوي (اسم المنتج • العدد • السعر)")
                    }
                }
            }
        }

        // Invoice Items (3 fields: Product Name, Quantity, Price)
        if (draft.items.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "الفاتورة فارغة حالياً",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "امسح QR Code المنتج أو اختر من المخزون أو أضف بنداً يدوياً لتعديل الاسم والعدد والسعر.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(draft.items, key = { it.localId }) { row ->
                InvoiceLineItemEditorCard(
                    row = row,
                    currency = profile.currency,
                    onNameChange = { viewModel.updateDraftItem(row.localId, nameText = it) },
                    onQuantityChange = { viewModel.updateDraftItem(row.localId, quantityText = it) },
                    onPriceChange = { viewModel.updateDraftItem(row.localId, priceText = it) },
                    onAdjustQty = { delta -> viewModel.adjustDraftItemQuantity(row.localId, delta) },
                    onRemove = { viewModel.removeDraftItem(row.localId) }
                )
            }
        }

        // Invoice Summary & Payment Card
        item {
            val taxAmount = draft.taxAmount(profile.taxRatePercent)
            val grandTotal = draft.grandTotal(profile.taxRatePercent)

            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "ملخص الفاتورة والدفع",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = draft.customerName,
                            onValueChange = { viewModel.updateInvoiceMeta(customerName = it) },
                            label = { Text("اسم العميل (اختياري)") },
                            singleLine = true,
                            modifier = Modifier.weight(1.2f)
                        )
                        OutlinedTextField(
                            value = draft.discountText,
                            onValueChange = { viewModel.updateInvoiceMeta(discountText = it) },
                            label = { Text("الخصم (${profile.currency})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(0.8f)
                        )
                    }

                    Text(
                        text = "طريقة الدفع",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PaymentMethod.entries.forEach { method ->
                            FilterChip(
                                selected = draft.paymentMethod == method,
                                onClick = { viewModel.updateInvoiceMeta(paymentMethod = method) },
                                label = { Text(method.arabicLabel) }
                            )
                        }
                    }

                    HorizontalDivider()

                    SummaryLine("المجموع الفرعي", "${formatMoney(draft.subtotal)} ${profile.currency}")
                    if (draft.discountAmount > 0.0) {
                        SummaryLine("الخصم", "-${formatMoney(draft.discountAmount)} ${profile.currency}")
                    }
                    SummaryLine(
                        "الضريبة (${formatMoney(profile.taxRatePercent)}%)",
                        "${formatMoney(taxAmount)} ${profile.currency}"
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الإجمالي النهائي",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${formatMoney(grandTotal)} ${profile.currency}",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Button(
                        onClick = { viewModel.completeAndSaveInvoice() },
                        enabled = draft.items.isNotEmpty() && !draft.isSaving,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("complete_save_invoice_button")
                    ) {
                        if (draft.isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("جاري الحفظ والمزامنة...")
                        } else {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("إصدار وحفظ الفاتورة سحابياً", style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }

    if (showScannerSheet) {
        BarcodeScannerModalSheet(
            title = "مسح QR Code / باركود المنتج",
            onBarcodeDetected = { code ->
                showScannerSheet = false
                viewModel.addBarcodeOrProductToInvoice(code)
            },
            onDismiss = { showScannerSheet = false }
        )
    }

    if (showProductPicker) {
        ModalBottomSheet(
            onDismissRequest = { showProductPicker = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "اختر منتجاً من المخزون",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (products.isEmpty()) {
                    Text(
                        text = "لا توجد منتجات في المخزون بعد. أضف منتجات من شاشة المخزون.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.height(320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(products, key = { it.id }) { prod ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.addProductDirectlyToInvoice(prod)
                                        showProductPicker = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(prod.name, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "باركود: ${prod.barcode} • المتوفر: ${prod.quantity}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = "${formatMoney(prod.unitPrice)} ${profile.currency}",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InvoiceLineItemEditorCard(
    row: DraftInvoiceRow,
    currency: String,
    onNameChange: (String) -> Unit,
    onQuantityChange: (String) -> Unit,
    onPriceChange: (String) -> Unit,
    onAdjustQty: (Long) -> Unit,
    onRemove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (row.barcode.isNotBlank()) {
                    Text(
                        text = "QR/Barcode: ${row.barcode}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        text = "بند يدوي",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "المجموع: ${formatMoney(row.lineTotal)} $currency",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = onRemove) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "حذف المنتج",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // Field 1: Product Name
            OutlinedTextField(
                value = row.nameText,
                onValueChange = onNameChange,
                label = { Text("1. اسم المنتج") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Fields 2 & 3: Quantity and Price (manually editable)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1.1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { onAdjustQty(-1L) },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "إنقاص العدد")
                    }
                    OutlinedTextField(
                        value = row.quantityText,
                        onValueChange = { input ->
                            onQuantityChange(input.filter { it.isDigit() })
                        },
                        label = { Text("2. العدد") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { onAdjustQty(1L) },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "زيادة العدد")
                    }
                }

                OutlinedTextField(
                    value = row.priceText,
                    onValueChange = onPriceChange,
                    label = { Text("3. السعر ($currency)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(0.9f)
                )
            }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
    }
}
