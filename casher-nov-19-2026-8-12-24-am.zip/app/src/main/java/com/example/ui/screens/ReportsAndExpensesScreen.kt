package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.export.ExcelReportExporter
import com.example.security.FinancialPinLockScreen
import com.example.viewmodel.CasherViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsAndExpensesScreen(
    profileState: UiState<StoreProfile>,
    productsState: UiState<List<Product>>,
    invoicesState: UiState<List<Invoice>>,
    expensesState: UiState<List<Expense>>,
    selectedDayKey: String,
    selectedMonthKey: String,
    isVaultUnlocked: Boolean,
    viewModel: CasherViewModel,
    modifier: Modifier = Modifier
) {
    val profile = (profileState as? UiState.Success)?.data ?: StoreProfile()
    if (profile.pinEnabled && !isVaultUnlocked) {
        FinancialPinLockScreen(
            expectedHash = profile.pinHash,
            onUnlocked = { viewModel.unlockFinancialVault() },
            modifier = modifier
        )
        return
    }

    val context = LocalContext.current
    val products = (productsState as? UiState.Success)?.data ?: emptyList()
    val invoices = (invoicesState as? UiState.Success)?.data ?: emptyList()
    val expenses = (expensesState as? UiState.Success)?.data ?: emptyList()

    var activeTab by remember { mutableIntStateOf(0) } // 0 = Reports, 1 = Daily Expenses
    var reportPeriodMode by remember { mutableIntStateOf(0) } // 0 = Daily, 1 = Monthly
    var showExpenseDialog by remember { mutableStateOf(false) }

    val saveExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    ExcelReportExporter.writeMonthlyExcelReport(
                        monthKey = selectedMonthKey,
                        storeName = profile.storeName,
                        currency = profile.currency,
                        invoices = invoices,
                        expenses = expenses,
                        products = products,
                        outputStream = out
                    )
                }
                viewModel.showFeedback("تم تصدير التقرير المالي لشهر $selectedMonthKey بصيغة Excel بنجاح")
            } catch (e: Exception) {
                viewModel.showFeedback("تعذر تصدير ملف Excel: ${e.localizedMessage}")
            }
        }
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            if (activeTab == 1) {
                FloatingActionButton(
                    onClick = { showExpenseDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("add_expense_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة مصروف يومي")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.weight(1f)) {
                    SegmentedButton(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Text("التقارير المالية")
                    }
                    SegmentedButton(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) {
                        Text("المصاريف اليومية")
                    }
                }
                if (profile.pinEnabled) {
                    IconButton(
                        onClick = { viewModel.lockFinancialVault() },
                        modifier = Modifier.testTag("lock_financial_vault_button")
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "قفل البيانات المالية")
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            if (activeTab == 0) {
                val filteredInvoices = if (reportPeriodMode == 0) {
                    invoices.filter { it.dayKey == selectedDayKey }
                } else {
                    invoices.filter { it.monthKey == selectedMonthKey }
                }
                val filteredExpenses = if (reportPeriodMode == 0) {
                    expenses.filter { it.dayKey == selectedDayKey }
                } else {
                    expenses.filter { it.monthKey == selectedMonthKey }
                }

                val totalSales = filteredInvoices.sumOf { it.totalAmount }
                val totalExpenses = filteredExpenses.sumOf { it.amount }
                val netProfit = totalSales - totalExpenses

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    // Daily / Monthly Switcher + Date Stepper
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(
                                        selected = reportPeriodMode == 0,
                                        onClick = { reportPeriodMode = 0 },
                                        label = { Text("التقرير اليومي") }
                                    )
                                    FilterChip(
                                        selected = reportPeriodMode == 1,
                                        onClick = { reportPeriodMode = 1 },
                                        label = { Text("التقرير الشهري") }
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = {
                                            if (reportPeriodMode == 0) {
                                                viewModel.setSelectedDayKey(shiftDayKey(selectedDayKey, -1))
                                            } else {
                                                viewModel.setSelectedMonthKey(shiftMonthKey(selectedMonthKey, -1))
                                            }
                                        }
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "السابق")
                                    }
                                    Text(
                                        text = if (reportPeriodMode == 0) "يوم: $selectedDayKey" else "شهر: $selectedMonthKey",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    IconButton(
                                        onClick = {
                                            if (reportPeriodMode == 0) {
                                                viewModel.setSelectedDayKey(shiftDayKey(selectedDayKey, 1))
                                            } else {
                                                viewModel.setSelectedMonthKey(shiftMonthKey(selectedMonthKey, 1))
                                            }
                                        }
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "التالي")
                                    }
                                }
                            }
                        }
                    }

                    // 2x2 KPI Cards
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ReportKpiCard(
                                    label = "إجمالي المبيعات",
                                    value = "${formatMoney(totalSales)} ${profile.currency}",
                                    accent = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.weight(1f)
                                )
                                ReportKpiCard(
                                    label = "إجمالي المصاريف",
                                    value = "${formatMoney(totalExpenses)} ${profile.currency}",
                                    accent = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                ReportKpiCard(
                                    label = "صافي الربح",
                                    value = "${formatMoney(netProfit)} ${profile.currency}",
                                    accent = if (netProfit >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.weight(1f)
                                )
                                ReportKpiCard(
                                    label = "عدد الفواتير",
                                    value = "${filteredInvoices.size} فاتورة",
                                    accent = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // Sales vs Expenses Chart
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "تحليل المبيعات مقابل المصاريف",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                SalesVsExpenseChart(
                                    sales = totalSales,
                                    expenses = totalExpenses,
                                    profit = netProfit.coerceAtLeast(0.0),
                                    salesColor = MaterialTheme.colorScheme.primary,
                                    expenseColor = MaterialTheme.colorScheme.error,
                                    profitColor = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }

                    // Payment Methods Breakdown
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "توزيع طرق الدفع",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                PaymentMethod.entries.forEach { method ->
                                    val sum = filteredInvoices
                                        .filter { it.paymentMethod == method.name }
                                        .sumOf { it.totalAmount }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(method.arabicLabel)
                                        Text(
                                            text = "${formatMoney(sum)} ${profile.currency}",
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Excel Monthly Export Card
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "تصدير التقرير المالي الشهري (Excel)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "ينشئ ملف .xlsx يحتوي على 4 أوراق عمل: الملخص المالي، فواتير المبيعات، المصاريف اليومية، والمخزون لشهر $selectedMonthKey.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            saveExcelLauncher.launch("casher_report_$selectedMonthKey.xlsx")
                                        },
                                        modifier = Modifier.weight(1f).testTag("export_excel_button")
                                    ) {
                                        Icon(Icons.Default.TableView, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("حفظ ملف Excel")
                                    }
                                    IconButton(
                                        onClick = {
                                            val uri = ExcelReportExporter.exportExcelToCacheAndShare(
                                                context = context,
                                                monthKey = selectedMonthKey,
                                                storeName = profile.storeName,
                                                currency = profile.currency,
                                                invoices = invoices,
                                                expenses = expenses,
                                                products = products
                                            )
                                            ExcelReportExporter.shareExcelUri(context, uri, selectedMonthKey)
                                        }
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "مشاركة Excel")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // Daily Expenses Tab
                if (expenses.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "لا توجد مصاريف مسجلة بعد",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "اضغط + لتسجيل المصاريف اليومية ومزامنتها سحابياً.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 88.dp)
                    ) {
                        items(expenses, key = { it.id }) { exp ->
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(exp.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${exp.category} • ${exp.dayKey}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (!exp.notes.isNullOrBlank()) {
                                            Text(
                                                text = exp.notes,
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${formatMoney(exp.amount)} ${profile.currency}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                    IconButton(onClick = { viewModel.deleteExpense(exp.id) }) {
                                        Icon(
                                            Icons.Default.DeleteOutline,
                                            contentDescription = "حذف المصروف",
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showExpenseDialog) {
        AddExpenseDialog(
            currency = profile.currency,
            onDismiss = { showExpenseDialog = false },
            onSave = { title, category, amount, notes ->
                viewModel.upsertExpense(
                    title = title,
                    category = category,
                    amount = amount,
                    dayKey = CasherViewModel.todayDayKey(),
                    notes = notes
                )
                showExpenseDialog = false
            }
        )
    }
}

@Composable
private fun ReportKpiCard(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }
    }
}

@Composable
private fun SalesVsExpenseChart(
    sales: Double,
    expenses: Double,
    profit: Double,
    salesColor: Color,
    expenseColor: Color,
    profitColor: Color
) {
    val maxVal = maxOf(sales, expenses, profit, 1.0)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            val barWidth = size.width / 6f
            val items = listOf(
                sales.toFloat() to salesColor,
                expenses.toFloat() to expenseColor,
                profit.toFloat() to profitColor
            )
            items.forEachIndexed { idx, (value, color) ->
                val ratio = (value / maxVal.toFloat()).coerceIn(0.04f, 1f)
                val barHeight = size.height * ratio
                val x = (idx * 2 + 0.5f) * barWidth
                drawRoundRect(
                    color = color,
                    topLeft = Offset(x, size.height - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(14f, 14f)
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Text("المبيعات", style = MaterialTheme.typography.labelMedium, color = salesColor, fontWeight = FontWeight.Bold)
            Text("المصاريف", style = MaterialTheme.typography.labelMedium, color = expenseColor, fontWeight = FontWeight.Bold)
            Text("صافي الربح", style = MaterialTheme.typography.labelMedium, color = profitColor, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AddExpenseDialog(
    currency: String,
    onDismiss: () -> Unit,
    onSave: (String, String, Double, String?) -> Unit
) {
    val categories = listOf("مشتريات بضاعة", "إيجار", "رواتب", "فواتير ومرافق", "صيانة", "أخرى")
    var title by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(categories.first()) }
    var amountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل مصروف يومي") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("بيان المصروف") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("expense_title_input")
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("المبلغ ($currency)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("expense_amount_input")
                )
                Text("التصنيف:", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.drop(3).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorMsg != null) {
                    Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.replace(',', '.').toDoubleOrNull()
                    if (title.isBlank() || amt == null || amt <= 0.0) {
                        errorMsg = "يرجى إدخال بيان المصروف ومبلغ أكبر من صفر."
                        return@Button
                    }
                    onSave(title.trim(), selectedCategory, amt, notes.trim().takeIf { it.isNotEmpty() })
                },
                modifier = Modifier.testTag("save_expense_button")
            ) {
                Text("حفظ المصروف")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

private fun shiftDayKey(dayKey: String, deltaDays: Int): String {
    return try {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        cal.time = fmt.parse(dayKey)!!
        cal.add(Calendar.DAY_OF_MONTH, deltaDays)
        fmt.format(cal.time)
    } catch (_: Exception) {
        dayKey
    }
}

private fun shiftMonthKey(monthKey: String, deltaMonths: Int): String {
    return try {
        val fmt = SimpleDateFormat("yyyy-MM", Locale.US)
        val cal = Calendar.getInstance()
        cal.time = fmt.parse(monthKey)!!
        cal.add(Calendar.MONTH, deltaMonths)
        fmt.format(cal.time)
    } catch (_: Exception) {
        monthKey
    }
}
