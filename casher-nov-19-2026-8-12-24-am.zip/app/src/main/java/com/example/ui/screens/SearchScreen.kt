package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.Product
import com.example.data.model.StoreProfile
import com.example.data.model.UiState

@Composable
fun SearchScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    profileState: UiState<StoreProfile>,
    productsState: UiState<List<Product>>,
    invoicesState: UiState<List<Invoice>>,
    expensesState: UiState<List<Expense>>,
    isVaultUnlocked: Boolean,
    modifier: Modifier = Modifier
) {
    val profile = (profileState as? UiState.Success)?.data ?: StoreProfile()
    val products = (productsState as? UiState.Success)?.data ?: emptyList()
    val invoices = (invoicesState as? UiState.Success)?.data ?: emptyList()
    val expenses = (expensesState as? UiState.Success)?.data ?: emptyList()
    val hideFinancials = profile.pinEnabled && !isVaultUnlocked

    val matchedProducts = if (query.isBlank()) emptyList() else products.filter {
        it.name.contains(query, ignoreCase = true) || it.barcode.contains(query, ignoreCase = true)
    }
    val matchedInvoices = if (query.isBlank()) emptyList() else invoices.filter { inv ->
        inv.invoiceNumber.contains(query, ignoreCase = true) ||
            (inv.customerName?.contains(query, ignoreCase = true) == true) ||
            inv.items.any { it.productName.contains(query, ignoreCase = true) }
    }
    val matchedExpenses = if (query.isBlank() || hideFinancials) emptyList() else expenses.filter {
        it.title.contains(query, ignoreCase = true) || it.category.contains(query, ignoreCase = true)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("ابحث في المنتجات، الباركود، الفواتير، والمصاريف...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().testTag("global_search_input")
        )
        Spacer(Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            if (query.isBlank()) {
                item {
                    Text(
                        text = "اكتب كلمة البحث أو رقم الباركود أو رقم الفاتورة للوصول السريع.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                if (matchedProducts.isNotEmpty()) {
                    item {
                        Text("المنتجات (${matchedProducts.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    items(matchedProducts, key = { "p_${it.id}" }) { p ->
                        SearchResultCard(
                            title = p.name,
                            subtitle = "باركود: ${p.barcode} • الكمية: ${p.quantity}",
                            trailing = "${formatMoney(p.unitPrice)} ${profile.currency}"
                        )
                    }
                }
                if (matchedInvoices.isNotEmpty()) {
                    item {
                        Text("الفواتير (${matchedInvoices.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    items(matchedInvoices, key = { "i_${it.id}" }) { inv ->
                        SearchResultCard(
                            title = inv.invoiceNumber,
                            subtitle = "${inv.dayKey} • ${inv.items.size} أصناف",
                            trailing = if (hideFinancials) "••••" else "${formatMoney(inv.totalAmount)} ${profile.currency}"
                        )
                    }
                }
                if (matchedExpenses.isNotEmpty()) {
                    item {
                        Text("المصاريف (${matchedExpenses.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    items(matchedExpenses, key = { "e_${it.id}" }) { exp ->
                        SearchResultCard(
                            title = exp.title,
                            subtitle = "${exp.category} • ${exp.dayKey}",
                            trailing = "${formatMoney(exp.amount)} ${profile.currency}"
                        )
                    }
                }
                if (matchedProducts.isEmpty() && matchedInvoices.isEmpty() && matchedExpenses.isEmpty()) {
                    item {
                        Text(
                            text = "لا توجد نتائج مطابقة لـ \"$query\".",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchResultCard(
    title: String,
    subtitle: String,
    trailing: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(trailing, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}
