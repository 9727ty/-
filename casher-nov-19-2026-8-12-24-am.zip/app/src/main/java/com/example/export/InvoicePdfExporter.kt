package com.example.export

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.Invoice
import com.example.data.model.PaymentMethod
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object InvoicePdfExporter {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842

    fun writeInvoicePdf(
        invoice: Invoice,
        storeName: String,
        currency: String,
        outputStream: OutputStream
    ) {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = document.startPage(pageInfo)
        drawInvoiceOnCanvas(page.canvas, invoice, storeName, currency)
        document.finishPage(page)
        document.writeTo(outputStream)
        document.close()
    }

    fun exportInvoiceToCacheAndShare(
        context: Context,
        invoice: Invoice,
        storeName: String,
        currency: String
    ): Uri {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val safeName = invoice.invoiceNumber.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "$safeName.pdf")
        FileOutputStream(file).use { out ->
            writeInvoicePdf(invoice, storeName, currency, out)
        }
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun sharePdfUri(context: Context, uri: Uri, invoiceNumber: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "فاتورة مبيعات $invoiceNumber")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة / حفظ الفاتورة PDF"))
    }

    fun printInvoice(
        context: Context,
        invoice: Invoice,
        storeName: String,
        currency: String
    ) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val jobName = "Casher_${invoice.invoiceNumber}"

        val adapter = object : PrintDocumentAdapter() {
            private var pdfDocument: PrintedPdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?
            ) {
                pdfDocument = PrintedPdfDocument(context, newAttributes)
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("${invoice.invoiceNumber}.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                val doc = pdfDocument ?: return
                val page = doc.startPage(0)
                if (cancellationSignal?.isCanceled == true) {
                    callback.onWriteCancelled()
                    doc.close()
                    return
                }
                drawInvoiceOnCanvas(page.canvas, invoice, storeName, currency)
                doc.finishPage(page)
                try {
                    FileOutputStream(destination.fileDescriptor).use { out ->
                        doc.writeTo(out)
                    }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                } finally {
                    doc.close()
                    pdfDocument = null
                }
            }
        }
        printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    }

    private fun drawInvoiceOnCanvas(
        canvas: Canvas,
        invoice: Invoice,
        storeName: String,
        currency: String
    ) {
        val margin = 40f
        val rightEdge = PAGE_WIDTH - margin
        var y = 52f

        val headerBgPaint = Paint().apply { color = Color.parseColor("#0B3B36") }
        canvas.drawRoundRect(margin, 28f, rightEdge, 118f, 14f, 14f, headerBgPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.RIGHT
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D1FAE5")
            textSize = 13f
            textAlign = Paint.Align.RIGHT
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 12.5f
            textAlign = Paint.Align.RIGHT
        }
        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.RIGHT
        }
        val leftBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.LEFT
        }
        val leftNormalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 12.5f
            textAlign = Paint.Align.LEFT
        }
        val linePaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            strokeWidth = 1.2f
        }

        canvas.drawText(storeName, rightEdge - 16f, 65f, titlePaint)
        canvas.drawText("فاتورة مبيعات ضريبية مبسطة | casher POS", rightEdge - 16f, 92f, subtitlePaint)

        y = 148f
        val dateText = invoice.createdAt?.toDate()?.let {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(it)
        } ?: invoice.dayKey

        canvas.drawText("رقم الفاتورة: ${invoice.invoiceNumber}", rightEdge, y, boldPaint)
        canvas.drawText("التاريخ: $dateText", margin, y, leftNormalPaint)
        y += 22f
        val paymentLabel = PaymentMethod.fromRaw(invoice.paymentMethod).arabicLabel
        canvas.drawText("طريقة الدفع: $paymentLabel", rightEdge, y, labelPaint)
        if (!invoice.customerName.isNullOrBlank()) {
            canvas.drawText("العميل: ${invoice.customerName}", margin, y, leftNormalPaint)
        }

        y += 20f
        canvas.drawLine(margin, y, rightEdge, y, linePaint)
        y += 24f

        // Table Header
        val headerRowPaint = Paint().apply { color = Color.parseColor("#E9F0EE") }
        canvas.drawRect(margin, y - 18f, rightEdge, y + 10f, headerRowPaint)
        canvas.drawText("المنتج", rightEdge - 8f, y, boldPaint)
        canvas.drawText("العدد", margin + 210f, y, leftBoldPaint)
        canvas.drawText("السعر", margin + 120f, y, leftBoldPaint)
        canvas.drawText("الإجمالي", margin + 8f, y, leftBoldPaint)
        y += 26f

        for (item in invoice.items) {
            if (y > PAGE_HEIGHT - 160f) break
            val displayName = item.productName.take(28)
            canvas.drawText(displayName, rightEdge - 8f, y, labelPaint)
            canvas.drawText(item.quantity.toString(), margin + 210f, y, leftNormalPaint)
            canvas.drawText(String.format(Locale.US, "%.2f", item.unitPrice), margin + 120f, y, leftNormalPaint)
            canvas.drawText(String.format(Locale.US, "%.2f", item.lineTotal), margin + 8f, y, leftBoldPaint)
            y += 22f
            canvas.drawLine(margin, y - 8f, rightEdge, y - 8f, linePaint)
        }

        y += 16f
        canvas.drawText("المجموع الفرعي:", rightEdge, y, labelPaint)
        canvas.drawText("${String.format(Locale.US, "%.2f", invoice.subtotal)} $currency", margin, y, leftNormalPaint)
        y += 20f
        if (invoice.discountAmount > 0.0) {
            canvas.drawText("الخصم:", rightEdge, y, labelPaint)
            canvas.drawText("-${String.format(Locale.US, "%.2f", invoice.discountAmount)} $currency", margin, y, leftNormalPaint)
            y += 20f
        }
        canvas.drawText("الضريبة:", rightEdge, y, labelPaint)
        canvas.drawText("${String.format(Locale.US, "%.2f", invoice.taxAmount)} $currency", margin, y, leftNormalPaint)
        y += 26f

        val totalBoxPaint = Paint().apply { color = Color.parseColor("#D1FAE5") }
        canvas.drawRoundRect(margin, y - 20f, rightEdge, y + 14f, 10f, 10f, totalBoxPaint)
        val grandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0B3B36")
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.RIGHT
        }
        val grandLeftPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0B3B36")
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.LEFT
        }
        canvas.drawText("الإجمالي المستحق:", rightEdge - 12f, y + 2f, grandPaint)
        canvas.drawText("${String.format(Locale.US, "%.2f", invoice.totalAmount)} $currency", margin + 12f, y + 2f, grandLeftPaint)

        if (!invoice.notes.isNullOrBlank()) {
            y += 38f
            canvas.drawText("ملاحظات: ${invoice.notes}", rightEdge, y, labelPaint)
        }
    }
}
