package com.example.export

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ExcelReportExporter {

    fun writeMonthlyExcelReport(
        monthKey: String,
        storeName: String,
        currency: String,
        invoices: List<Invoice>,
        expenses: List<Expense>,
        products: List<Product>,
        outputStream: OutputStream
    ) {
        val monthInvoices = invoices.filter { it.monthKey == monthKey }
        val monthExpenses = expenses.filter { it.monthKey == monthKey }
        val totalSales = monthInvoices.sumOf { it.totalAmount }
        val totalTax = monthInvoices.sumOf { it.taxAmount }
        val totalDiscount = monthInvoices.sumOf { it.discountAmount }
        val totalExpenses = monthExpenses.sumOf { it.amount }
        val netProfit = totalSales - totalExpenses

        val summaryRows = listOf(
            listOf(Cell.Str("تقرير الأداء المالي الشهري - $storeName", bold = true), Cell.Str(monthKey, bold = true)),
            listOf(Cell.Str("البند", bold = true), Cell.Str("القيمة ($currency)", bold = true)),
            listOf(Cell.Str("إجمالي المبيعات"), Cell.Num(totalSales)),
            listOf(Cell.Str("عدد الفواتير"), Cell.Num(monthInvoices.size.toDouble())),
            listOf(Cell.Str("إجمالي الضريبة المحصلة"), Cell.Num(totalTax)),
            listOf(Cell.Str("إجمالي الخصومات"), Cell.Num(totalDiscount)),
            listOf(Cell.Str("إجمالي المصاريف"), Cell.Num(totalExpenses)),
            listOf(Cell.Str("صافي الربح", bold = true), Cell.Num(netProfit, bold = true)),
            listOf(Cell.Str("عدد الأصناف بالمخزون"), Cell.Num(products.size.toDouble())),
            listOf(Cell.Str("إجمالي وحدات المخزون"), Cell.Num(products.sumOf { it.quantity }.toDouble()))
        )

        val invoiceRows = mutableListOf<List<Cell>>(
            listOf(
                Cell.Str("رقم الفاتورة", bold = true),
                Cell.Str("التاريخ", bold = true),
                Cell.Str("العميل", bold = true),
                Cell.Str("طريقة الدفع", bold = true),
                Cell.Str("المجموع الفرعي", bold = true),
                Cell.Str("الضريبة", bold = true),
                Cell.Str("الخصم", bold = true),
                Cell.Str("الإجمالي", bold = true),
                Cell.Str("تفاصيل المنتجات", bold = true)
            )
        )
        monthInvoices.forEach { inv ->
            val itemsSummary = inv.items.joinToString(" | ") { "${it.productName} (${it.quantity}×${it.unitPrice})" }
            invoiceRows.add(
                listOf(
                    Cell.Str(inv.invoiceNumber),
                    Cell.Str(inv.dayKey),
                    Cell.Str(inv.customerName.orEmpty()),
                    Cell.Str(PaymentMethod.fromRaw(inv.paymentMethod).arabicLabel),
                    Cell.Num(inv.subtotal),
                    Cell.Num(inv.taxAmount),
                    Cell.Num(inv.discountAmount),
                    Cell.Num(inv.totalAmount),
                    Cell.Str(itemsSummary)
                )
            )
        }

        val expenseRows = mutableListOf<List<Cell>>(
            listOf(
                Cell.Str("التاريخ", bold = true),
                Cell.Str("البند", bold = true),
                Cell.Str("التصنيف", bold = true),
                Cell.Str("المبلغ ($currency)", bold = true),
                Cell.Str("ملاحظات", bold = true)
            )
        )
        monthExpenses.forEach { exp ->
            expenseRows.add(
                listOf(
                    Cell.Str(exp.dayKey),
                    Cell.Str(exp.title),
                    Cell.Str(exp.category),
                    Cell.Num(exp.amount),
                    Cell.Str(exp.notes.orEmpty())
                )
            )
        }

        val inventoryRows = mutableListOf<List<Cell>>(
            listOf(
                Cell.Str("الباركود", bold = true),
                Cell.Str("اسم المنتج", bold = true),
                Cell.Str("الكمية المتوفرة", bold = true),
                Cell.Str("سعر البيع", bold = true),
                Cell.Str("سعر التكلفة", bold = true),
                Cell.Str("التصنيف", bold = true)
            )
        )
        products.forEach { prod ->
            inventoryRows.add(
                listOf(
                    Cell.Str(prod.barcode),
                    Cell.Str(prod.name),
                    Cell.Num(prod.quantity.toDouble()),
                    Cell.Num(prod.unitPrice),
                    Cell.Num(prod.costPrice ?: 0.0),
                    Cell.Str(prod.category.orEmpty())
                )
            )
        }

        ZipOutputStream(outputStream).use { zip ->
            writeZipEntry(zip, "[Content_Types].xml", contentTypesXml())
            writeZipEntry(zip, "_rels/.rels", rootRelsXml())
            writeZipEntry(zip, "xl/workbook.xml", workbookXml())
            writeZipEntry(zip, "xl/_rels/workbook.xml.rels", workbookRelsXml())
            writeZipEntry(zip, "xl/styles.xml", stylesXml())
            writeZipEntry(zip, "xl/worksheets/sheet1.xml", buildSheetXml(summaryRows))
            writeZipEntry(zip, "xl/worksheets/sheet2.xml", buildSheetXml(invoiceRows))
            writeZipEntry(zip, "xl/worksheets/sheet3.xml", buildSheetXml(expenseRows))
            writeZipEntry(zip, "xl/worksheets/sheet4.xml", buildSheetXml(inventoryRows))
        }
    }

    fun exportExcelToCacheAndShare(
        context: Context,
        monthKey: String,
        storeName: String,
        currency: String,
        invoices: List<Invoice>,
        expenses: List<Expense>,
        products: List<Product>
    ): Uri {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "casher_report_$monthKey.xlsx")
        FileOutputStream(file).use { out ->
            writeMonthlyExcelReport(monthKey, storeName, currency, invoices, expenses, products, out)
        }
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun shareExcelUri(context: Context, uri: Uri, monthKey: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "تقرير casher المالي لشهر $monthKey")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة / تصدير تقرير Excel"))
    }

    private sealed interface Cell {
        data class Str(val value: String, val bold: Boolean = false) : Cell
        data class Num(val value: Double, val bold: Boolean = false) : Cell
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun escapeXml(input: String): String {
        return buildString(input.length) {
            for (ch in input) {
                when (ch) {
                    '&' -> append("&amp;")
                    '<' -> append("&lt;")
                    '>' -> append("&gt;")
                    '"' -> append("&quot;")
                    '\'' -> append("&apos;")
                    else -> if (ch.code >= 0x20 || ch == '\t' || ch == '\n' || ch == '\r') append(ch)
                }
            }
        }
    }

    private fun colLetter(index: Int): String {
        var i = index
        val sb = StringBuilder()
        while (i >= 0) {
            sb.insert(0, ('A'.code + (i % 26)).toChar())
            i = i / 26 - 1
        }
        return sb.toString()
    }

    private fun buildSheetXml(rows: List<List<Cell>>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sb.append("""<sheetViews><sheetView rightToLeft="1" workbookViewId="0"/></sheetViews>""")
        sb.append("""<sheetData>""")
        rows.forEachIndexed { rIdx, row ->
            val rowNum = rIdx + 1
            sb.append("""<row r="$rowNum">""")
            row.forEachIndexed { cIdx, cell ->
                val ref = "${colLetter(cIdx)}$rowNum"
                when (cell) {
                    is Cell.Str -> {
                        val style = if (cell.bold) """ s="1"""" else ""
                        sb.append("""<c r="$ref" t="inlineStr"$style><is><t>${escapeXml(cell.value)}</t></is></c>""")
                    }
                    is Cell.Num -> {
                        val style = if (cell.bold) """ s="1"""" else ""
                        val formatted = String.format(Locale.US, "%.2f", cell.value)
                        sb.append("""<c r="$ref"$style><v>$formatted</v></c>""")
                    }
                }
            }
            sb.append("""</row>""")
        }
        sb.append("""</sheetData></worksheet>""")
        return sb.toString()
    }

    private fun contentTypesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>"""

    private fun rootRelsXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

    private fun workbookXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="الملخص المالي" sheetId="1" r:id="rId1"/>
    <sheet name="فواتير المبيعات" sheetId="2" r:id="rId2"/>
    <sheet name="المصاريف اليومية" sheetId="3" r:id="rId3"/>
    <sheet name="المخزون" sheetId="4" r:id="rId4"/>
  </sheets>
</workbook>"""

    private fun workbookRelsXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/>
  <Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/>
  <Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    private fun stylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><color rgb="FF0B3B36"/><name val="Calibri"/></font>
  </fonts>
  <fills count="2">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
  </fills>
  <borders count="1">
    <border><left/><right/><top/><bottom/><diagonal/></border>
  </borders>
  <cellStyleXfs count="1">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
  </cellStyleXfs>
  <cellXfs count="2">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
  </cellXfs>
</styleSheet>"""
}
