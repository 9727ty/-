package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.data.firebase.CasherRepository
import com.example.data.firebase.authStateFlow
import com.example.hardware.BluetoothScannerManager
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.InvoicesHistoryScreen
import com.example.ui.screens.NewInvoiceScreen
import com.example.ui.screens.ReportsAndExpensesScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CasherTheme
import com.example.viewmodel.CasherViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

object NavRoutes {
    const val DASHBOARD = "dashboard"
    const val NEW_INVOICE = "new_invoice"
    const val INVENTORY = "inventory"
    const val INVOICES_HISTORY = "invoices_history"
    const val REPORTS_EXPENSES = "reports_expenses"
    const val SEARCH = "search"
    const val SETTINGS = "settings"
}

private data class BottomNavTab(
    val route: String,
    val label: String,
    val icon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CasherTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            CasherMainShell(currentUserId = user.uid)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CasherMainShell(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val bluetoothManager = remember(currentUserId) {
        BluetoothScannerManager(context.applicationContext, scope)
    }

    DisposableEffect(currentUserId) {
        onDispose { bluetoothManager.disconnect() }
    }

    val viewModel: CasherViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                CasherViewModel(CasherRepository(db), currentUserId)
            }
        }
    )

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: NavRoutes.DASHBOARD

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val productsState by viewModel.productsState.collectAsStateWithLifecycle()
    val invoicesState by viewModel.invoicesState.collectAsStateWithLifecycle()
    val expensesState by viewModel.expensesState.collectAsStateWithLifecycle()
    val invoiceDraft by viewModel.invoiceDraft.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedDayKey by viewModel.selectedDayKey.collectAsStateWithLifecycle()
    val selectedMonthKey by viewModel.selectedMonthKey.collectAsStateWithLifecycle()
    val isVaultUnlocked by viewModel.isFinancialVaultUnlocked.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.feedbackMessage.collectAsStateWithLifecycle()
    val btStatus by bluetoothManager.status.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    // Route Bluetooth SPP scanned barcodes directly into the active Invoice when not on Inventory
    LaunchedEffect(bluetoothManager, currentRoute) {
        bluetoothManager.scannedCodes.collect { code ->
            if (currentRoute != NavRoutes.INVENTORY) {
                viewModel.addBarcodeOrProductToInvoice(code)
                if (currentRoute != NavRoutes.NEW_INVOICE) {
                    navController.navigate(NavRoutes.NEW_INVOICE) {
                        launchSingleTop = true
                    }
                }
            }
        }
    }

    val tabs = remember {
        listOf(
            BottomNavTab(NavRoutes.DASHBOARD, "الرئيسية", Icons.Default.Home),
            BottomNavTab(NavRoutes.NEW_INVOICE, "فاتورة", Icons.Default.AddShoppingCart),
            BottomNavTab(NavRoutes.INVENTORY, "المخزون", Icons.Default.Inventory2),
            BottomNavTab(NavRoutes.INVOICES_HISTORY, "السجل", Icons.AutoMirrored.Filled.ReceiptLong),
            BottomNavTab(NavRoutes.REPORTS_EXPENSES, "التقارير", Icons.Default.BarChart)
        )
    }

    val screenTitle = when (currentRoute) {
        NavRoutes.DASHBOARD -> "casher"
        NavRoutes.NEW_INVOICE -> "فاتورة مبيعات جديدة"
        NavRoutes.INVENTORY -> "إدارة المخزون"
        NavRoutes.INVOICES_HISTORY -> "سجل الفواتير"
        NavRoutes.REPORTS_EXPENSES -> "المصاريف والتقارير المالية"
        NavRoutes.SEARCH -> "البحث داخل التطبيق"
        NavRoutes.SETTINGS -> "الإعدادات والحماية"
        else -> "casher"
    }

    val isTopTab = tabs.any { it.route == currentRoute }
    val useNavRail = LocalConfiguration.current.screenWidthDp >= 600

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = screenTitle,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (!isTopTab) {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }
                    }
                },
                actions = {
                    if (currentRoute != NavRoutes.SEARCH) {
                        IconButton(onClick = { navController.navigate(NavRoutes.SEARCH) }) {
                            Icon(Icons.Default.Search, contentDescription = "بحث")
                        }
                    }
                    if (currentRoute != NavRoutes.SETTINGS) {
                        IconButton(onClick = { navController.navigate(NavRoutes.SETTINGS) }) {
                            Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            if (!useNavRail && isTopTab) {
                NavigationBar {
                    tabs.forEach { tab ->
                        val selected = navBackStackEntry?.destination?.hierarchy?.any {
                            it.route == tab.route
                        } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = { navigateToTab(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (useNavRail && isTopTab) {
                NavigationRail {
                    tabs.forEach { tab ->
                        val selected = navBackStackEntry?.destination?.hierarchy?.any {
                            it.route == tab.route
                        } == true
                        NavigationRailItem(
                            selected = selected,
                            onClick = { navigateToTab(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                NavHost(
                    navController = navController,
                    startDestination = NavRoutes.DASHBOARD
                ) {
                    composable(NavRoutes.DASHBOARD) {
                        DashboardScreen(
                            profileState = profileState,
                            productsState = productsState,
                            invoicesState = invoicesState,
                            expensesState = expensesState,
                            btStatus = btStatus,
                            isVaultUnlocked = isVaultUnlocked,
                            onNavigateNewInvoice = { navigateToTab(NavRoutes.NEW_INVOICE) },
                            onNavigateInventory = { navigateToTab(NavRoutes.INVENTORY) },
                            onNavigateInvoicesHistory = { navigateToTab(NavRoutes.INVOICES_HISTORY) },
                            onNavigateReportsAndExpenses = { navigateToTab(NavRoutes.REPORTS_EXPENSES) },
                            onNavigateSearch = { navController.navigate(NavRoutes.SEARCH) },
                            onNavigateSettings = { navController.navigate(NavRoutes.SETTINGS) }
                        )
                    }
                    composable(NavRoutes.NEW_INVOICE) {
                        NewInvoiceScreen(
                            draft = invoiceDraft,
                            profileState = profileState,
                            productsState = productsState,
                            viewModel = viewModel
                        )
                    }
                    composable(NavRoutes.INVENTORY) {
                        InventoryScreen(
                            productsState = productsState,
                            profileState = profileState,
                            bluetoothScannedCodes = bluetoothManager.scannedCodes,
                            viewModel = viewModel
                        )
                    }
                    composable(NavRoutes.INVOICES_HISTORY) {
                        InvoicesHistoryScreen(
                            invoicesState = invoicesState,
                            profileState = profileState,
                            viewModel = viewModel
                        )
                    }
                    composable(NavRoutes.REPORTS_EXPENSES) {
                        ReportsAndExpensesScreen(
                            profileState = profileState,
                            productsState = productsState,
                            invoicesState = invoicesState,
                            expensesState = expensesState,
                            selectedDayKey = selectedDayKey,
                            selectedMonthKey = selectedMonthKey,
                            isVaultUnlocked = isVaultUnlocked,
                            viewModel = viewModel
                        )
                    }
                    composable(NavRoutes.SEARCH) {
                        SearchScreen(
                            query = searchQuery,
                            onQueryChange = { viewModel.updateSearchQuery(it) },
                            profileState = profileState,
                            productsState = productsState,
                            invoicesState = invoicesState,
                            expensesState = expensesState,
                            isVaultUnlocked = isVaultUnlocked
                        )
                    }
                    composable(NavRoutes.SETTINGS) {
                        SettingsScreen(
                            profileState = profileState,
                            bluetoothManager = bluetoothManager,
                            btStatus = btStatus,
                            viewModel = viewModel,
                            onBeforeSignOut = { bluetoothManager.disconnect() }
                        )
                    }
                }
            }
        }
    }
}
