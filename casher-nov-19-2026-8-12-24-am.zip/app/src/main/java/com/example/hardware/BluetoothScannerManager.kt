package com.example.hardware

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

data class PairedBluetoothDeviceUi(
    val name: String,
    val address: String
)

sealed interface BluetoothScannerStatus {
    data object Disconnected : BluetoothScannerStatus
    data class Connecting(val deviceName: String) : BluetoothScannerStatus
    data class Connected(val deviceName: String, val address: String) : BluetoothScannerStatus
    data class Error(val message: String) : BluetoothScannerStatus
}

class BluetoothScannerManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val adapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _status = MutableStateFlow<BluetoothScannerStatus>(BluetoothScannerStatus.Disconnected)
    val status: StateFlow<BluetoothScannerStatus> = _status.asStateFlow()

    private val _scannedCodes = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val scannedCodes: SharedFlow<String> = _scannedCodes.asSharedFlow()

    private var activeSocket: BluetoothSocket? = null
    private var readerJob: Job? = null

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun isBluetoothAvailableAndEnabled(): Boolean {
        return adapter != null && adapter.isEnabled
    }

    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<PairedBluetoothDeviceUi> {
        if (!hasBluetoothPermission() || adapter == null || !adapter.isEnabled) return emptyList()
        return try {
            adapter.bondedDevices
                ?.map { device ->
                    PairedBluetoothDeviceUi(
                        name = device.name?.takeIf { it.isNotBlank() } ?: "ماسح بلوتوث",
                        address = device.address
                    )
                }
                ?.sortedBy { it.name }
                ?: emptyList()
        } catch (e: SecurityException) {
            Log.w("BtScanner", "Missing Bluetooth permission", e)
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(address: String, displayName: String) {
        if (!hasBluetoothPermission()) {
            _status.value = BluetoothScannerStatus.Error("يرجى منح صلاحية البلوتوث أولاً.")
            return
        }
        val btAdapter = adapter
        if (btAdapter == null || !btAdapter.isEnabled) {
            _status.value = BluetoothScannerStatus.Error("البلوتوث غير مفعل على الجهاز.")
            return
        }

        disconnect()
        _status.value = BluetoothScannerStatus.Connecting(displayName)

        readerJob = scope.launch(Dispatchers.IO) {
            try {
                val device: BluetoothDevice = btAdapter.getRemoteDevice(address)
                btAdapter.cancelDiscovery()
                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                activeSocket = socket
                socket.connect()
                _status.value = BluetoothScannerStatus.Connected(
                    deviceName = displayName,
                    address = address
                )

                val reader = BufferedReader(InputStreamReader(socket.inputStream))
                while (isActive && socket.isConnected) {
                    val line = reader.readLine() ?: break
                    val cleaned = line.trim()
                    if (cleaned.isNotEmpty()) {
                        _scannedCodes.emit(cleaned)
                    }
                }
            } catch (e: Exception) {
                Log.w("BtScanner", "Bluetooth SPP connection ended: ${e.message}", e)
                _status.value = BluetoothScannerStatus.Error(
                    "تعذر الاتصال بالماسح ($displayName). تأكد أن الماسح في وضع SPP ومقترن."
                )
            }
        }
    }

    fun disconnect() {
        readerJob?.cancel()
        readerJob = null
        try {
            activeSocket?.close()
        } catch (_: Exception) {
        }
        activeSocket = null
        _status.value = BluetoothScannerStatus.Disconnected
    }

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}
