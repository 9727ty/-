package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.CasherRepository
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceLineItem
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.StoreProfile
import com.example.data.model.UiState
import com.example.security.SecurityUtils
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class DraftInvoiceRow(
    val localId: String = UUID.randomUUID().toString(),
    val productId: String = "",
    val barcode: String = "",
    val nameText: String = "",
    val quantityText: String = "1",
    val priceText: String = "0.0"
) {
    val parsedQuantity: Long
        get() = quantityText.toLongOrNull()?.coerceAtLeast(1L) ?: 1L

    val parsedPrice: Double
        get() = priceText.replace(',', '.').toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0

    val lineTotal: Double
        get() = parsedQuantity * parsedPrice
}

data class InvoiceDraftUiState(
    val items: List<DraftInvoiceRow> = emptyList(),
    val customerName: String = "",
    val discountText: String = "0",
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val notes: String = "",
    val isSaving: Boolean = false,
    val lastCompletedInvoice: Invoice? = null
) {
    val subtotal: Double
        get() = items.sumOf { it.lineTotal }

    val discountAmount: Double
        get() = (discountText.replace(',', '.').toDoubleOrNull() ?: 0.0).coerceIn(0.0, subtotal)

    fun taxAmount(taxRatePercent: Double): Double {
        val taxable = (subtotal - discountAmount).coerceAtLeast(0.0)
        return taxable * (taxRatePercent.coerceIn(0.0, 100.0) / 100.0)
    }

    fun grandTotal(taxRatePercent: Double): Double {
        return (subtotal - discountAmount + taxAmount(taxRatePercent)).coerceAtLeast(0.0)
    }
}

class CasherViewModel(
    private val repository: CasherRepository,
    val currentUserId: String
) : ViewModel() {

    val profileState: StateFlow<UiState<StoreProfile>> = repository.observeStoreProfile(currentUserId)
        .map<StoreProfile, UiState<StoreProfile>> { UiState.Success(it) }
        .catch { error -> emit(handleStreamError("StoreProfile", error)) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val productsState: StateFlow<UiState<List<Product>>> = repository.observeProducts(currentUserId)
        .map<List<Product>, UiState<List<Product>>> { UiState.Success(it) }
        .catch { error -> emit(handleStreamError("Products", error)) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val invoicesState: StateFlow<UiState<List<Invoice>>> = repository.observeInvoices(currentUserId)
        .map<List<Invoice>, UiState<List<Invoice>>> { UiState.Success(it) }
        .catch { error -> emit(handleStreamError("Invoices", error)) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    val expensesState: StateFlow<UiState<List<Expense>>> = repository.observeExpenses(currentUserId)
        .map<List<Expense>, UiState<List<Expense>>> { UiState.Success(it) }
        .catch { error -> emit(handleStreamError("Expenses", error)) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    private val _invoiceDraft = MutableStateFlow(InvoiceDraftUiState())
    val invoiceDraft: StateFlow<InvoiceDraftUiState> = _invoiceDraft.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedDayKey = MutableStateFlow(todayDayKey())
    val selectedDayKey: StateFlow<String> = _selectedDayKey.asStateFlow()

    private val _selectedMonthKey = MutableStateFlow(currentMonthKey())
    val selectedMonthKey: StateFlow<String> = _selectedMonthKey.asStateFlow()

    private val _isFinancialVaultUnlocked = MutableStateFlow(false)
    val isFinancialVaultUnlocked: StateFlow<Boolean> = _isFinancialVaultUnlocked.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private fun handleStreamError(label: String, error: Throwable): UiState.Error {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing $label", rootError)
        return UiState.Error(rootError.message ?: "تعذر تحميل البيانات من السحابة.")
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun showFeedback(message: String) {
        _feedbackMessage.value = message
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedDayKey(dayKey: String) {
        _selectedDayKey.value = dayKey
    }

    fun setSelectedMonthKey(monthKey: String) {
        _selectedMonthKey.value = monthKey
    }

    fun unlockFinancialVault() {
        _isFinancialVaultUnlocked.value = true
    }

    fun lockFinancialVault() {
        _isFinancialVaultUnlocked.value = false
    }

    fun addBarcodeOrProductToInvoice(barcode: String) {
        val cleanCode = barcode.trim()
        if (cleanCode.isEmpty()) return

        val products = (productsState.value as? UiState.Success)?.data ?: emptyList()
        val matched = products.firstOrNull { it.barcode.equals(cleanCode, ignoreCase = true) }

        _invoiceDraft.update { draft ->
            val existingIdx = draft.items.indexOfFirst {
                (matched != null && it.productId == matched.id) ||
                    (it.barcode.isNotBlank() && it.barcode.equals(cleanCode, ignoreCase = true))
            }
            if (existingIdx >= 0) {
                val updatedList = draft.items.toMutableList()
                val current = updatedList[existingIdx]
                val nextQty = current.parsedQuantity + 1L
                updatedList[existingIdx] = current.copy(quantityText = nextQty.toString())
                draft.copy(items = updatedList, lastCompletedInvoice = null)
            } else if (matched != null) {
                val newRow = DraftInvoiceRow(
                    productId = matched.id,
                    barcode = matched.barcode,
                    nameText = matched.name,
                    quantityText = "1",
                    priceText = formatPriceInput(matched.unitPrice)
                )
                draft.copy(items = draft.items + newRow, lastCompletedInvoice = null)
            } else {
                val newRow = DraftInvoiceRow(
                    barcode = cleanCode,
                    nameText = "منتج ($cleanCode)",
                    quantityText = "1",
                    priceText = "0.0"
                )
                draft.copy(items = draft.items + newRow, lastCompletedInvoice = null)
            }
        }

        if (matched != null) {
            _feedbackMessage.value = "تمت إضافة ${matched.name} إلى الفاتورة"
        } else {
            _feedbackMessage.value = "تمت إضافة الرمز $cleanCode — يمكنك تعديل الاسم والسعر يدوياً"
        }
    }

    fun addProductDirectlyToInvoice(product: Product) {
        _invoiceDraft.update { draft ->
            val existingIdx = draft.items.indexOfFirst { it.productId == product.id }
            if (existingIdx >= 0) {
                val updatedList = draft.items.toMutableList()
                val current = updatedList[existingIdx]
                updatedList[existingIdx] = current.copy(
                    quantityText = (current.parsedQuantity + 1L).toString()
                )
                draft.copy(items = updatedList, lastCompletedInvoice = null)
            } else {
                draft.copy(
                    items = draft.items + DraftInvoiceRow(
                        productId = product.id,
                        barcode = product.barcode,
                        nameText = product.name,
                        quantityText = "1",
                        priceText = formatPriceInput(product.unitPrice)
                    ),
                    lastCompletedInvoice = null
                )
            }
        }
    }

    fun addBlankManualItemToInvoice() {
        _invoiceDraft.update { draft ->
            if (draft.items.size >= 50) return@update draft
            draft.copy(
                items = draft.items + DraftInvoiceRow(
                    nameText = "",
                    quantityText = "1",
                    priceText = ""
                ),
                lastCompletedInvoice = null
            )
        }
    }

    fun updateDraftItem(
        localId: String,
        nameText: String? = null,
        quantityText: String? = null,
        priceText: String? = null
    ) {
        _invoiceDraft.update { draft ->
            val updated = draft.items.map { row ->
                if (row.localId == localId) {
                    row.copy(
                        nameText = nameText ?: row.nameText,
                        quantityText = quantityText ?: row.quantityText,
                        priceText = priceText ?: row.priceText
                    )
                } else {
                    row
                }
            }
            draft.copy(items = updated)
        }
    }

    fun adjustDraftItemQuantity(localId: String, delta: Long) {
        _invoiceDraft.update { draft ->
            val updated = draft.items.mapNotNull { row ->
                if (row.localId == localId) {
                    val next = row.parsedQuantity + delta
                    if (next <= 0L) null else row.copy(quantityText = next.toString())
                } else {
                    row
                }
            }
            draft.copy(items = updated)
        }
    }

    fun removeDraftItem(localId: String) {
        _invoiceDraft.update { draft ->
            draft.copy(items = draft.items.filterNot { it.localId == localId })
        }
    }

    fun updateInvoiceMeta(
        customerName: String? = null,
        discountText: String? = null,
        paymentMethod: PaymentMethod? = null,
        notes: String? = null
    ) {
        _invoiceDraft.update { draft ->
            draft.copy(
                customerName = customerName ?: draft.customerName,
                discountText = discountText ?: draft.discountText,
                paymentMethod = paymentMethod ?: draft.paymentMethod,
                notes = notes ?: draft.notes
            )
        }
    }

    fun clearInvoiceDraft() {
        _invoiceDraft.value = InvoiceDraftUiState()
    }

    fun completeAndSaveInvoice() {
        val draft = _invoiceDraft.value
        if (draft.isSaving) return
        val validRows = draft.items.filter { it.nameText.trim().isNotEmpty() }
        if (validRows.isEmpty()) {
            _feedbackMessage.value = "يرجى إضافة منتج واحد على الأقل باسم صحيح."
            return
        }
        if (validRows.size > 50) {
            _feedbackMessage.value = "الحد الأقصى 50 منتجاً في الفاتورة الواحدة."
            return
        }

        val profile = (profileState.value as? UiState.Success)?.data ?: StoreProfile()
        val products = (productsState.value as? UiState.Success)?.data ?: emptyList()

        val lineItems = validRows.map { row ->
            val qty = row.parsedQuantity
            val price = row.parsedPrice
            InvoiceLineItem(
                productId = row.productId,
                barcode = row.barcode,
                productName = row.nameText.trim(),
                quantity = qty,
                unitPrice = price,
                lineTotal = qty * price
            )
        }
        val subtotal = lineItems.sumOf { it.lineTotal }
        val discount = draft.discountAmount.coerceIn(0.0, subtotal)
        val tax = ((subtotal - discount).coerceAtLeast(0.0)) * (profile.taxRatePercent / 100.0)
        val total = (subtotal - discount + tax).coerceAtLeast(0.0)
        val invoiceNum = generateInvoiceNumber()

        val invoice = Invoice(
            userId = currentUserId,
            invoiceNumber = invoiceNum,
            customerName = draft.customerName.trim().takeIf { it.isNotEmpty() },
            items = lineItems,
            subtotal = subtotal,
            taxAmount = tax,
            discountAmount = discount,
            totalAmount = total,
            paymentMethod = draft.paymentMethod.name,
            monthKey = currentMonthKey(),
            dayKey = todayDayKey(),
            notes = draft.notes.trim().takeIf { it.isNotEmpty() }
        )

        _invoiceDraft.update { it.copy(isSaving = true) }
        viewModelScope.launch {
            val result = repository.createInvoiceAndDeductStock(currentUserId, invoice, products)
            result.onSuccess { savedInvoice ->
                _invoiceDraft.value = InvoiceDraftUiState(lastCompletedInvoice = savedInvoice)
                _feedbackMessage.value = "تم حفظ الفاتورة ${savedInvoice.invoiceNumber} ومزامنتها سحابياً"
            }.onFailure { err ->
                _invoiceDraft.update { it.copy(isSaving = false) }
                _feedbackMessage.value = "فشل حفظ الفاتورة: ${err.localizedMessage ?: "خطأ غير متوقع"}"
            }
        }
    }

    fun upsertProduct(
        existingId: String = "",
        barcode: String,
        name: String,
        quantity: Long,
        unitPrice: Double,
        costPrice: Double?,
        category: String?,
        minStockAlert: Long?
    ) {
        viewModelScope.launch {
            val product = Product(
                id = existingId,
                userId = currentUserId,
                barcode = barcode.trim(),
                name = name.trim(),
                quantity = quantity.coerceAtLeast(0L),
                unitPrice = unitPrice.coerceAtLeast(0.0),
                costPrice = costPrice?.coerceAtLeast(0.0),
                category = category?.trim()?.takeIf { it.isNotEmpty() },
                minStockAlert = minStockAlert?.coerceAtLeast(0L)
            )
            repository.upsertProduct(currentUserId, product)
                .onSuccess {
                    _feedbackMessage.value = if (existingId.isBlank()) "تمت إضافة المنتج للمخزون" else "تم تحديث بيانات المنتج"
                }
                .onFailure {
                    _feedbackMessage.value = it.localizedMessage ?: "تعذر حفظ المنتج"
                }
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            repository.deleteProduct(currentUserId, productId)
                .onSuccess { _feedbackMessage.value = "تم حذف المنتج من المخزون" }
                .onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر حذف المنتج" }
        }
    }

    fun upsertExpense(
        existingId: String = "",
        title: String,
        category: String,
        amount: Double,
        dayKey: String = todayDayKey(),
        notes: String? = null
    ) {
        val cleanMonth = if (dayKey.length >= 7) dayKey.substring(0, 7) else currentMonthKey()
        viewModelScope.launch {
            val expense = Expense(
                id = existingId,
                userId = currentUserId,
                title = title.trim(),
                category = category.trim().ifBlank { "أخرى" },
                amount = amount,
                monthKey = cleanMonth,
                dayKey = dayKey,
                notes = notes?.trim()?.takeIf { it.isNotEmpty() }
            )
            repository.upsertExpense(currentUserId, expense)
                .onSuccess { _feedbackMessage.value = "تم حفظ المصروف اليومي بنجاح" }
                .onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر حفظ المصروف" }
        }
    }

    fun deleteExpense(expenseId: String) {
        viewModelScope.launch {
            repository.deleteExpense(currentUserId, expenseId)
                .onSuccess { _feedbackMessage.value = "تم حذف المصروف" }
                .onFailure { _feedbackMessage.value = it.localizedMessage ?: "تعذر حذف المصروف" }
        }
    }

    fun saveStoreSettings(
        storeName: String,
        currency: String,
        taxRatePercent: Double,
        pinEnabled: Boolean,
        newRawPin: String?,
        bluetoothScannerName: String?,
        bluetoothScannerAddress: String?
    ) {
        val currentProfile = (profileState.value as? UiState.Success)?.data ?: StoreProfile()
        val computedPinHash = when {
            !pinEnabled -> currentProfile.pinHash
            !newRawPin.isNullOrBlank() && newRawPin.length == 4 -> SecurityUtils.hashPin(newRawPin)
            else -> currentProfile.pinHash
        }
        viewModelScope.launch {
            repository.saveStoreProfile(
                userId = currentUserId,
                storeName = storeName,
                currency = currency,
                taxRatePercent = taxRatePercent,
                pinEnabled = pinEnabled && !computedPinHash.isNullOrBlank(),
                pinHash = computedPinHash,
                bluetoothScannerName = bluetoothScannerName ?: currentProfile.bluetoothScannerName,
                bluetoothScannerAddress = bluetoothScannerAddress ?: currentProfile.bluetoothScannerAddress
            ).onSuccess {
                _feedbackMessage.value = "تم حفظ الإعدادات ومزامنتها سحابياً"
            }.onFailure {
                _feedbackMessage.value = it.localizedMessage ?: "تعذر حفظ الإعدادات"
            }
        }
    }

    companion object {
        private const val TAG = "CasherVM"
        private const val STOP_TIMEOUT_MILLIS = 5000L

        fun todayDayKey(): String {
            return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        }

        fun currentMonthKey(): String {
            return SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        }

        fun generateInvoiceNumber(): String {
            val stamp = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date())
            return "INV-$stamp"
        }

        fun formatPriceInput(value: Double): String {
            return if (value % 1.0 == 0.0) value.toLong().toString()
            else String.format(Locale.US, "%.2f", value)
        }
    }
}
