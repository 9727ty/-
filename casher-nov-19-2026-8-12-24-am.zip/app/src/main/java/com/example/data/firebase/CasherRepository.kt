package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.model.Expense
import com.example.data.model.Invoice
import com.example.data.model.InvoiceLineItem
import com.example.data.model.PaymentMethod
import com.example.data.model.Product
import com.example.data.model.StoreProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlin.math.max

class CasherRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("يجب تسجيل الدخول بحساب Google أولاً.")
    }

    private fun usersDoc(uid: String) = db.collection("users").document(uid)
    private fun productsCol(uid: String) = usersDoc(uid).collection("products")
    private fun invoicesCol(uid: String) = usersDoc(uid).collection("invoices")
    private fun expensesCol(uid: String) = usersDoc(uid).collection("expenses")

    fun observeStoreProfile(userId: String): Flow<StoreProfile> = flow {
        val docRef = usersDoc(userId)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            StoreProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        ) ?: StoreProfile(id = userId, userId = userId)
                    } else {
                        StoreProfile(id = userId, userId = userId)
                    }
                }
                .catch { error ->
                    handleFlowException(error, OperationType.GET, docRef.path, userId)
                }
        )
    }

    fun observeProducts(userId: String): Flow<List<Product>> = flow {
        val col = productsCol(userId)
        emitAll(
            col.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Product::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.name }
                }
                .catch { error ->
                    handleFlowException(error, OperationType.LIST, col.path, userId)
                }
        )
    }

    fun observeInvoices(userId: String): Flow<List<Invoice>> = flow {
        val col = invoicesCol(userId)
        emitAll(
            col.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Invoice::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowException(error, OperationType.LIST, col.path, userId)
                }
        )
    }

    fun observeExpenses(userId: String): Flow<List<Expense>> = flow {
        val col = expensesCol(userId)
        emitAll(
            col.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Expense::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowException(error, OperationType.LIST, col.path, userId)
                }
        )
    }

    private fun handleFlowException(
        error: Throwable,
        operationType: OperationType,
        path: String,
        uid: String
    ): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
        throw error
    }

    suspend fun saveStoreProfile(
        userId: String,
        storeName: String,
        currency: String,
        taxRatePercent: Double,
        pinEnabled: Boolean,
        pinHash: String?,
        bluetoothScannerName: String?,
        bluetoothScannerAddress: String?
    ): Result<Unit> {
        val docPath = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "تغير المستخدم المسجل، يرجى إعادة المحاولة." }
            val cleanStoreName = storeName.trim().take(80).ifBlank { "متجر casher" }
            val cleanCurrency = currency.trim().take(12).ifBlank { "ر.س" }
            val safeTax = taxRatePercent.coerceIn(0.0, 100.0)
            val docRef = usersDoc(userId)
            val existingSnap = docRef.get().await()

            if (!existingSnap.exists()) {
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("storeName", cleanStoreName)
                    put("currency", cleanCurrency)
                    put("taxRatePercent", safeTax)
                    put("pinEnabled", pinEnabled)
                    if (!pinHash.isNullOrBlank()) put("pinHash", pinHash.take(128))
                    if (!bluetoothScannerName.isNullOrBlank()) put("bluetoothScannerName", bluetoothScannerName.take(80))
                    if (!bluetoothScannerAddress.isNullOrBlank()) put("bluetoothScannerAddress", bluetoothScannerAddress.take(64))
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "storeName" to cleanStoreName,
                    "currency" to cleanCurrency,
                    "taxRatePercent" to safeTax,
                    "pinEnabled" to pinEnabled,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (pinHash != null) updates["pinHash"] = pinHash.take(128)
                if (bluetoothScannerName != null) updates["bluetoothScannerName"] = bluetoothScannerName.take(80)
                if (bluetoothScannerAddress != null) updates["bluetoothScannerAddress"] = bluetoothScannerAddress.take(64)
                docRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertProduct(userId: String, product: Product): Result<Unit> {
        var docPath = "users/$userId/products"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "تغير المستخدم المسجل." }
            val barcode = product.barcode.trim().take(128)
            val name = product.name.trim().take(120)
            require(barcode.isNotBlank()) { "يرجى إدخال الباركود أو مسحه." }
            require(name.isNotBlank()) { "يرجى إدخال اسم المنتج." }
            val qty = product.quantity.coerceIn(0L, 1_000_000L)
            val unitPrice = product.unitPrice.coerceIn(0.0, 10_000_000.0)
            val costPrice = product.costPrice?.coerceIn(0.0, 10_000_000.0)
            val category = product.category?.trim()?.take(60)?.takeIf { it.isNotEmpty() }
            val minStock = product.minStockAlert?.coerceIn(0L, 100_000L)

            if (product.id.isBlank()) {
                val docRef = productsCol(userId).document()
                docPath = docRef.path
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("barcode", barcode)
                    put("name", name)
                    put("quantity", qty)
                    put("unitPrice", unitPrice)
                    if (costPrice != null) put("costPrice", costPrice)
                    if (category != null) put("category", category)
                    if (minStock != null) put("minStockAlert", minStock)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            } else {
                val docRef = productsCol(userId).document(product.id)
                docPath = docRef.path
                val updates = buildMap<String, Any> {
                    put("barcode", barcode)
                    put("name", name)
                    put("quantity", qty)
                    put("unitPrice", unitPrice)
                    if (costPrice != null) put("costPrice", costPrice)
                    if (category != null) put("category", category)
                    if (minStock != null) put("minStockAlert", minStock)
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(userId: String, productId: String): Result<Unit> {
        val docPath = "users/$userId/products/$productId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "تغير المستخدم المسجل." }
            require(productId.isNotBlank())
            productsCol(userId).document(productId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun createInvoiceAndDeductStock(
        userId: String,
        invoice: Invoice,
        inventoryProducts: List<Product>
    ): Result<Invoice> {
        var docPath = "users/$userId/invoices"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "تغير المستخدم المسجل." }
            require(invoice.items.isNotEmpty() && invoice.items.size <= 50) {
                "يجب أن تحتوي الفاتورة على منتج واحد على الأقل (حد أقصى 50)."
            }

            val invoiceDocRef = invoicesCol(userId).document()
            docPath = invoiceDocRef.path

            val itemMaps = invoice.items.map { item ->
                mapOf(
                    "productId" to item.productId.take(128),
                    "barcode" to item.barcode.take(128),
                    "productName" to item.productName.trim().take(120),
                    "quantity" to item.quantity.coerceAtLeast(1L),
                    "unitPrice" to item.unitPrice.coerceAtLeast(0.0),
                    "lineTotal" to item.lineTotal.coerceAtLeast(0.0)
                )
            }

            val payment = PaymentMethod.fromRaw(invoice.paymentMethod).name
            val payload = buildMap<String, Any> {
                put("userId", uid)
                put("invoiceNumber", invoice.invoiceNumber.trim().take(40))
                invoice.customerName?.trim()?.take(80)?.takeIf { it.isNotEmpty() }?.let {
                    put("customerName", it)
                }
                put("items", itemMaps)
                put("subtotal", invoice.subtotal.coerceAtLeast(0.0))
                put("taxAmount", invoice.taxAmount.coerceAtLeast(0.0))
                put("discountAmount", invoice.discountAmount.coerceAtLeast(0.0))
                put("totalAmount", invoice.totalAmount.coerceAtLeast(0.0))
                put("paymentMethod", payment)
                put("monthKey", invoice.monthKey)
                put("dayKey", invoice.dayKey)
                invoice.notes?.trim()?.take(250)?.takeIf { it.isNotEmpty() }?.let {
                    put("notes", it)
                }
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
            }

            val batch = db.batch()
            batch.set(invoiceDocRef, payload)

            // Aggregate stock deductions per productId
            val deductionsByProductId = mutableMapOf<String, Long>()
            for (item in invoice.items) {
                val matchedProduct = when {
                    item.productId.isNotBlank() -> inventoryProducts.firstOrNull { it.id == item.productId }
                    item.barcode.isNotBlank() -> inventoryProducts.firstOrNull { it.barcode == item.barcode }
                    else -> null
                }
                if (matchedProduct != null && matchedProduct.id.isNotBlank()) {
                    deductionsByProductId[matchedProduct.id] =
                        (deductionsByProductId[matchedProduct.id] ?: 0L) + item.quantity
                }
            }

            for ((productId, deductQty) in deductionsByProductId) {
                val prod = inventoryProducts.firstOrNull { it.id == productId } ?: continue
                val newQty = max(0L, prod.quantity - deductQty)
                val prodRef = productsCol(userId).document(productId)
                batch.update(
                    prodRef,
                    mapOf(
                        "quantity" to newQty,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            batch.commit().await()
            Result.success(invoice.copy(id = invoiceDocRef.id, userId = uid))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateInvoiceNotes(
        userId: String,
        invoiceId: String,
        customerName: String?,
        notes: String?
    ): Result<Unit> {
        val docPath = "users/$userId/invoices/$invoiceId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            require(invoiceId.isNotBlank())
            val updates = buildMap<String, Any> {
                customerName?.trim()?.take(80)?.let { put("customerName", it) }
                notes?.trim()?.take(250)?.let { put("notes", it) }
                put("updatedAt", FieldValue.serverTimestamp())
            }
            invoicesCol(userId).document(invoiceId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteInvoice(userId: String, invoiceId: String): Result<Unit> {
        val docPath = "users/$userId/invoices/$invoiceId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            require(invoiceId.isNotBlank())
            invoicesCol(userId).document(invoiceId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertExpense(userId: String, expense: Expense): Result<Unit> {
        var docPath = "users/$userId/expenses"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            val title = expense.title.trim().take(120)
            val category = expense.category.trim().take(60).ifBlank { "أخرى" }
            require(title.isNotBlank()) { "يرجى إدخال عنوان المصروف." }
            require(expense.amount > 0.0 && expense.amount <= 10_000_000.0) {
                "يرجى إدخال مبلغ صحيح أكبر من الصفر."
            }

            if (expense.id.isBlank()) {
                val docRef = expensesCol(userId).document()
                docPath = docRef.path
                val payload = buildMap<String, Any> {
                    put("userId", uid)
                    put("title", title)
                    put("category", category)
                    put("amount", expense.amount)
                    put("monthKey", expense.monthKey)
                    put("dayKey", expense.dayKey)
                    expense.notes?.trim()?.take(250)?.takeIf { it.isNotEmpty() }?.let {
                        put("notes", it)
                    }
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            } else {
                val docRef = expensesCol(userId).document(expense.id)
                docPath = docRef.path
                val updates = buildMap<String, Any> {
                    put("title", title)
                    put("category", category)
                    put("amount", expense.amount)
                    put("monthKey", expense.monthKey)
                    put("dayKey", expense.dayKey)
                    expense.notes?.trim()?.take(250)?.let { put("notes", it) }
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteExpense(userId: String, expenseId: String): Result<Unit> {
        val docPath = "users/$userId/expenses/$expenseId"
        return try {
            val uid = requireUserId()
            check(uid == userId)
            require(expenseId.isNotBlank())
            expensesCol(userId).document(expenseId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }
}
