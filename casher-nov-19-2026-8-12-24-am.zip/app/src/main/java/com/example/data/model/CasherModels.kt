package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class StoreProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val storeName: String = "متجر casher",
    val currency: String = "ر.س",
    val taxRatePercent: Double = 15.0,
    val pinEnabled: Boolean = false,
    val pinHash: String? = null,
    val bluetoothScannerName: String? = null,
    val bluetoothScannerAddress: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Product(
    @DocumentId val id: String = "",
    val userId: String = "",
    val barcode: String = "",
    val name: String = "",
    val quantity: Long = 0L,
    val unitPrice: Double = 0.0,
    val costPrice: Double? = null,
    val category: String? = null,
    val minStockAlert: Long? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class InvoiceLineItem(
    val productId: String = "",
    val barcode: String = "",
    val productName: String = "",
    val quantity: Long = 1L,
    val unitPrice: Double = 0.0,
    val lineTotal: Double = 0.0
)

@Keep
@IgnoreExtraProperties
data class Invoice(
    @DocumentId val id: String = "",
    val userId: String = "",
    val invoiceNumber: String = "",
    val customerName: String? = null,
    val items: List<InvoiceLineItem> = emptyList(),
    val subtotal: Double = 0.0,
    val taxAmount: Double = 0.0,
    val discountAmount: Double = 0.0,
    val totalAmount: Double = 0.0,
    val paymentMethod: String = PaymentMethod.CASH.name,
    val monthKey: String = "",
    val dayKey: String = "",
    val notes: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Expense(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val category: String = "مشتريات بضاعة",
    val amount: Double = 0.0,
    val monthKey: String = "",
    val dayKey: String = "",
    val notes: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class PaymentMethod(val arabicLabel: String) {
    CASH("نقدي"),
    CARD("بطاقة مدى / ائتمان"),
    TRANSFER("تحويل بنكي");

    companion object {
        fun fromRaw(raw: String?): PaymentMethod {
            return entries.firstOrNull { it.name == raw } ?: CASH
        }
    }
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
