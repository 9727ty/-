const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const DB_ID = "ai-studio-android-casher-010a3f6d-7fd0-44d9-b094-459b05ee27f5";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: denied all reads and writes", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore(DB_ID);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("products").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("products").doc("p1").set({
      userId: ALICE_UID,
      barcode: "123456",
      name: "Item",
      quantity: 10,
      unitPrice: 5.5,
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("StoreProfile: owner create, partial update, cross-user denial, and ghost field rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DB_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DB_ID);
  const ts = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      storeName: "متجر كاشير",
      currency: "ر.س",
      taxRatePercent: 15,
      pinEnabled: false,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      pinEnabled: true,
      pinHash: "a1b2c3d4",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Cross-user access denied
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      storeName: "Hacked",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Ghost field & future timestamp rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      storeName: "Future",
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Products: owner create, list, update quantity, delete, and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DB_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DB_ID);
  const ts = new Date(Date.now() - 5000);

  // Empty list query succeeds without undefined existing() property error
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("products").get()
  );

  // Create product mirroring ProductRepository payload (no `id` field)
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("products").doc("prod_1").set({
      userId: ALICE_UID,
      barcode: "6281000001234",
      name: "قهوة عربية مختصة",
      quantity: 25,
      unitPrice: 45.0,
      costPrice: 30.0,
      category: "مشروبات",
      minStockAlert: 5,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Partial update of quantity & price
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("products").doc("prod_1").update({
      quantity: 23,
      unitPrice: 48.0,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject negative quantity
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("products").doc("prod_1").update({
      quantity: -1,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Reject `@DocumentId` id key inside document body
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("products").doc("prod_2").set({
      id: "prod_2",
      userId: ALICE_UID,
      barcode: "999",
      name: "Bad",
      quantity: 1,
      unitPrice: 10.0,
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Bob cannot list, get, update, or delete Alice's products
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("products").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("products").doc("prod_1").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("products").doc("prod_1").delete());
});

test("Invoices: owner create, immutable financials on update, bounded items list", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DB_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DB_ID);
  const ts = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("invoices").doc("inv_1").set({
      userId: ALICE_UID,
      invoiceNumber: "INV-20261118-001",
      customerName: "عميل نقدي",
      items: [
        {
          productId: "prod_1",
          barcode: "6281000001234",
          productName: "قهوة عربية مختصة",
          quantity: 2,
          unitPrice: 45.0,
          lineTotal: 90.0,
        },
      ],
      subtotal: 90.0,
      taxAmount: 13.5,
      discountAmount: 0.0,
      totalAmount: 103.5,
      paymentMethod: "CASH",
      monthKey: "2026-11",
      dayKey: "2026-11-18",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Updating customerName / notes succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("invoices").doc("inv_1").update({
      notes: "تم التسليم",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Tampering totalAmount on update fails
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("invoices").doc("inv_1").update({
      totalAmount: 1.0,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Bob cannot list or read Alice's invoices
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("invoices").get());
});

test("Expenses: owner create, list, update, delete, and amount > 0 bound", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore(DB_ID);
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore(DB_ID);
  const ts = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("expenses").doc("exp_1").set({
      userId: ALICE_UID,
      title: "فاتورة كهرباء",
      category: "فواتير ومرافق",
      amount: 350.0,
      monthKey: "2026-11",
      dayKey: "2026-11-18",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  // Zero amount fails
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("expenses").doc("exp_2").set({
      userId: ALICE_UID,
      title: "Zero",
      category: "أخرى",
      amount: 0.0,
      monthKey: "2026-11",
      dayKey: "2026-11-18",
      createdAt: ts,
      updatedAt: ts,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("expenses").doc("exp_1").update({
      amount: 375.0,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("expenses").get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("expenses").doc("exp_1").delete()
  );
});
